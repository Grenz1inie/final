#ifndef RECOMMEND_EXEMPT_H
#define RECOMMEND_EXEMPT_H

#include"struct.h"
#include"header_and_tool.h"		

void build_extra_point_proof_linklist(void);
//int search_user(char*);
//void add_extra_point_proof(void);
void view_extra_point_proof(void);
void view_extra_point_policy(void);
void edit_extra_point_policy_selecting_part(void);
void edit_extra_point_policy_function_part(struct extra_point_policy*);
void add_extra_point_policy_linklist(void);
void build_extra_point_policy_linklist(void);
void extra_point_policy_linklist_dictionary_ordered_sorting(void);
void save_extra_point_policy_linklist(void);
void initial_extra_point_proof(struct extra_point_proof*);
void initial_extra_point_policy(struct extra_point_policy*);
void delet_extra_point_policy_linklist(void);
void _initial_extra_point_proof(struct extra_point_proof*);
void submit_extra_point_application(void);
void approve_extra_point_proof_selecting_part(void);
struct extra_point_proof* approve_extra_point_proof_function_part(struct extra_point_proof*, struct extra_point_proof*);
void submit_extra_point_application(void);
struct extra_point_proof* _build_extra_point_proof_linklist(struct extra_point_proof*);
void save_extra_point_proof_linklist(struct extra_point_proof*);
struct user* initial_user_info(struct user* target_user);
void search_extra_point_policy_linklist(void);


//ѧ�����������Ϣ�˵�
void recommend_exempt_menu(void)
{
	for (;;)
	{
		TimeDisplay = false;
		/*UI���*/
		{
			system("cls");
			SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
			printf("\033[1;1H[ESC] ����  [CTRL+Q] �˳�");
			draw_division_line();
			SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
			printf("\033[3;1H��ǰλ�ã����������Ϣ�˵�");
			SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
			printf("\033[9;0H[1] �鿴���˼ӷ���Ŀ\n[2] �鿴������ӷ���Ŀ\n[3] �ύ������ӷ�֤��");
			SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED);
			printf("\033[8;0H���°���ִ�в���");
			SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
			/*���ع��*/
			{
				hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
				CONSOLE_CURSOR_INFO cursorInfo;
				GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
				cursorInfo.bVisible = FALSE;						// ���ù��ɼ���ΪFALSE�����ع��  
				SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
			}
		}
		printf("\033[5;0H�ӷ�ǰ���㣺%.2lf\n�ӷֺ󼨵㣺%.2lf", plink_list_head->recommend_exempt_scores[0], plink_list_head->recommend_exempt_scores[1]);
		TimeDisplay = true;

		{
			/*���̼��*/
			char ch;
			{
				for (;;)
				{
					if (key_is_pressed())
					{
						if ((GetAsyncKeyState(VK_CONTROL) & 0x8000))
						{
							if ((GetAsyncKeyState(81) & 0x8000))					//Q
							{
								if (MessageBox(hwnd, _T("��ȷ��Ҫ�˳���"), _T("��ʾ"), MB_YESNO) == IDYES)
								{
									system("cls");
									plink_list_head->access %= 10;
									exit(0);
								}
								else
								{
									ch = '\0';
									break;
								}
							}
						}
						else
						{
							ch = _getch();
							break;
						}
					}
				}
			}
			/*����*/
			if (ch == 27)
			{
				return;
			}
			else if (ch == '1')
			{
				initial_extra_point_proof(plink_list_head->extra_point_proof_plinklist_head);
				view_extra_point_proof();
			}
			else if (ch == '2')
			{
				view_extra_point_policy();
			}
			else if (ch == '3')
			{
				submit_extra_point_application();
			}
		}
	}
	return;
}


//������ӷ���Ŀ ���� �˵�
void view_extra_point_policy(void)
{
	build_extra_point_policy_linklist();
	extra_point_policy_linklist_dictionary_ordered_sorting();
	if (plink_list_head->access % 10 == 0)
	{
		search_extra_point_policy_linklist();
		return;
	}
	bool flag = true;
	bool page_up_lock = true;
	bool page_down_lock = true;
	bool item_is_added = false;
	bool item_is_deleted = false;
	item_is_saved = false;
	int i = 0, j = 1;
	int current_page = 1;
	int total_page = 1;
	struct extra_point_policy* ptr = extra_point_policy_linklist_head_ptr;
	struct extra_point_policy* temp_ptr = ptr;
	for (;;)
	{
		if (flag)
		{

			/*UI���*/
			{
				///*���ڻ�*/
				//{
				//	SetWindowLong(hwnd, GWL_STYLE, (l_WinStyle | WS_POPUP) & ~WS_THICKFRAME);
				//	SetWindowPos(hwnd, HWND_TOP, WindowCenterX, WindowCenterY , WindowWidth, WindowHeight , 0);
				//}
				/*UI����*/
				{
					TimeDisplay = false;
					system("cls");
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
					if (plink_list_head->access % 10 == 2)
					{
						printf("\033[1;1H[ESC] ����  [CTRL+Q] �˳�  [CTRL+S] ����");
					}
					else
					{
						printf("\033[1;1H[ESC] ����  [CTRL+Q] �˳�");
					}
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
					draw_division_line();
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
					printf("\033[3;1H��ǰλ�ã�������ӷ���Ŀ�����˵�");
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
					if (plink_list_head->access % 10 == 2)
					{
						SetConsoleTextAttribute(hConsole, 14);
						printf("\033[6;0H\n[1] �༭��Ŀ\t[2] ������Ŀ\n[3] ������Ŀ\t[4] ɾ����Ŀ\t[����/AD] ��ҳ");
						SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED);
						printf("\033[5;0H���°���ִ�в���");
						SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
					}
					else
					{
						SetConsoleTextAttribute(hConsole, 14);
						printf("\033[6;0H[����/AD] ��ҳ");
						SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED);
						printf("\033[5;0H���°���ִ�в���");
						SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
					}
				}
				/*���ع��*/
				{
					HANDLE hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
					CONSOLE_CURSOR_INFO cursorInfo;
					GetConsoleCursorInfo(hStdout, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
					cursorInfo.bVisible = FALSE;					// ���ù��ɼ���ΪFALSE�����ع��  
					SetConsoleCursorInfo(hStdout, &cursorInfo);		// Ӧ���µĹ����Ϣ
				}
			}

			/*�ӷ����߶�ȡ��ӡ*/
			{
				if (item_is_saved)
				{
					build_extra_point_policy_linklist();
					ptr = extra_point_policy_linklist_head_ptr;
					item_is_saved = false;
				}
				extra_point_policy_linklist_dictionary_ordered_sorting();
				if (plink_list_head->access % 10 == 2)
				{
					printf("\033[11;0H");
				}
				else
				{
					printf("\033[8;0H");
				}
				if (extra_point_policy_linklist_head_ptr)
				{
					if (item_is_added)
					{
						ptr = extra_point_policy_linklist_head_ptr;
						current_page = 1;
						item_is_added = false;
					}
					if (item_is_deleted)
					{
						ptr = extra_point_policy_linklist_head_ptr;
						current_page = 1;
						item_is_deleted = false;
					}
					for (j = 1, temp_ptr = ptr; temp_ptr && j <= 10; temp_ptr = temp_ptr->next, i++, j++)
					{
						printf("%2d.[%c��]", j, temp_ptr->item_current_category);
						wprintf(L"%ls%ls", temp_ptr->item_current_name, temp_ptr->item_current_level);
						printf("���ӷ֣�%.*lf��\n", GetPrecision(temp_ptr->item_current_scores), temp_ptr->item_current_scores);
					}
					if (ptr->prev)
					{
						page_up_lock = false;
					}
					else
					{
						page_up_lock = true;
					}
					if (j > 10)
					{
						if (temp_ptr)
							page_down_lock = false;
					}
					else
					{
						page_down_lock = true;
					}
					int k = 1;
					for (struct extra_point_policy* p = extra_point_policy_linklist_head_ptr; p; p = p->next, k++);
					total_page = k / 10 + 1;
					SetConsoleTextAttribute(hConsole, 8);
					printf("\033[26;0H<��%d/%dҳ>", current_page, total_page);
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
				}
				else
				{
					printf("��");
				}
				flag = false;
				TimeDisplay = true;
			}
			flag = false;
		}
		/*���̼��*/
		char ch;
		{
			for (;;)
			{
				if (key_is_pressed())
				{
					if ((GetAsyncKeyState(VK_CONTROL) & 0x8000))
					{
						if ((GetAsyncKeyState(81) & 0x8000))
						{
							if (MessageBox(hwnd, _T("��ȷ��Ҫ�˳���"), _T("��ʾ"), MB_YESNO) == IDYES)
							{
								system("cls");
								plink_list_head->access %= 10;
								exit(0);
							}
							else
							{
								ch = '\0';
								break;
							}
						}
						if ((GetAsyncKeyState(83) & 0x8000))			//S
						{
							save_extra_point_policy_linklist();
							item_is_saved = true;
							flag = true;
							ch = '\0';
							initial_extra_point_policy(ptr);
							MessageBox(hwnd, _T("�ѱ���������"), _T("��ʾ"), MB_OK);
							while (_kbhit())
								_getch();

							log_file = fopen(LogName, "a");
							fprintf(log_file, "%s  ����Ա ���� ������ӷ���Ŀ\n\n", LogTime);
							fclose(log_file);


							break;
						}
					}
					else
					{
						ch = _getch();
						break;
					}
				}
			}
		}
		/*����*/
		if (ch == 27)
		{
			TimeDisplay = false;
			return;
		}
		/*��һҳ*/
		else if ((ch == 77 || ch == 'd' || ch == 'D') && !page_down_lock)
		{
			for (int k = 10; ptr && k > 0; k--, ptr = ptr->next);
			flag = true;
			current_page++;
			continue;
		}
		/*��һҳ*/
		else if ((ch == 75 || ch == 'a' || ch == 'A') && !page_up_lock)
		{
			for (int k = 10; ptr && k > 0; k--, ptr = ptr->prev);
			flag = true;
			current_page--;
			continue;
		}
		/*�༭�ӷ�����*/
		else if (plink_list_head->access % 10 == 2 && ch == '1')
		{
			edit_extra_point_policy_selecting_part();
			flag = true;
			i = 0, j = 1;
		}
		/*�����ӷ�����*/
		else if (plink_list_head->access % 10 == 2 && ch == '3')
		{
			add_extra_point_policy_linklist();
			i = 0, j = 1;
			flag = true;
			item_is_added = true;
		}
		/*ɾ���ӷ�����*/
		else if (plink_list_head->access % 10 == 2 && ch == '4')
		{
			delet_extra_point_policy_linklist();
			flag = true;
			i = 0, j = 1;
			item_is_deleted = true;
		}
		/*ɾ���ӷ�����*/
		else if (plink_list_head->access % 10 == 2 && ch == '2')
		{
			search_extra_point_policy_linklist();
			flag = true;
			i = 0, j = 1;
		}
	}
	return;
}

// ���ַ����ؼ��ֲ��Һ���  
wchar_t* wcsstr_custom(const wchar_t* wstr, const wchar_t* key)
{
	if (!wstr || !key) {
		return NULL;
	}

	const wchar_t* w = wstr;
	while (*w) {
		const wchar_t* k = key;
		const wchar_t* w_temp = w;

		// ����ַ��Ƚ�  
		while (*k && (*k == *w_temp)) {
			k++;
			w_temp++;
		}

		// ����ؼ���ƥ�䣬����ԭʼ���ַ����е�λ��  
		if (!*k) {
			return (wchar_t*)w;
		}

		// ��������  
		w++;
	}

	// ���û���ҵ�������NULL  
	return NULL;
}

//���Ҽӷ�����
void search_extra_point_policy_linklist(void)
{
	bool flag = true;
	bool flag1 = true;
	bool page_up_lock = true;
	bool page_down_lock = true;
	bool page_up_lock1 = true;
	bool page_down_lock1 = true;
	bool search_is_on = false;
	int i = 0, j = 1;
	int current_page = 1;
	int total_page = 1;
	int set = 0;
	int current_set = 0;
	struct extra_point_policy* ptr = extra_point_policy_linklist_head_ptr;
	struct extra_point_policy* temp_ptr = ptr;
	struct extra_point_policy* search_ptr = NULL;

	struct extra_point_policy* arr[64] = { 0 };
	wchar_t search_box[128] = { 0 };

	for (;;)
	{

		if (flag)
		{
			/*UI���*/
			{
				/*UI����*/
				{
					TimeDisplay = false;
					system("cls");
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
					printf("\033[1;1H[ESC] ����  [CTRL+Q] �˳� ");
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
					draw_division_line();
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
					printf("\033[3;1H��ǰλ�ã�����������ӷ���Ŀ�˵�");
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED);
					printf("\033[5;0H[ENTER] ��������ؼ���  [BACKSPACE] �������  [����/AD] ��ҳ");
					SetConsoleTextAttribute(hConsole, 14);
					if (search_box[0] == '\0')
						printf("\033[7;0H�����ؼ��֣�");
					else
					{
						wprintf(L"\033[7;0H�����ؼ��֣�");
						SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
						wprintf(L"%ls", search_box);
					}
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
				}
				/*���ع��*/
				{
					HANDLE hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
					CONSOLE_CURSOR_INFO cursorInfo;
					GetConsoleCursorInfo(hStdout, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
					cursorInfo.bVisible = FALSE;					// ���ù��ɼ���ΪFALSE�����ع��  
					SetConsoleCursorInfo(hStdout, &cursorInfo);		// Ӧ���µĹ����Ϣ
				}
			}

			/*�ӷ����߶�ȡ��ӡ*/
			{
				TimeDisplay = false;
				extra_point_policy_linklist_dictionary_ordered_sorting();
				printf("\033[9;0H");
				if (extra_point_policy_linklist_head_ptr)
				{
					if (!search_is_on)
					{
						for (j = 1, temp_ptr = ptr; temp_ptr && j <= 10; temp_ptr = temp_ptr->next, i++, j++)
						{
							printf("%2d.[%c��]", j, temp_ptr->item_current_category);
							wprintf(L"%ls%ls", temp_ptr->item_current_name, temp_ptr->item_current_level);
							printf("���ӷ֣�%.*lf��\n", GetPrecision(temp_ptr->item_current_scores), temp_ptr->item_current_scores);
						}
						if (ptr->prev)
						{
							page_up_lock = false;
						}
						else
						{
							page_up_lock = true;
						}
						if (j > 10)
						{
							if (temp_ptr)
								page_down_lock = false;
						}
						else
						{
							page_down_lock = true;
						}
						int k = 1;
						for (struct extra_point_policy* p = extra_point_policy_linklist_head_ptr; p; p = p->next, k++);
						total_page = k / 10 + 1;
						SetConsoleTextAttribute(hConsole, 8);
						printf("\033[26;0H<��%d/%dҳ>", current_page, total_page);
						SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
					}
					else
					{
						if (arr[0] != NULL)
						{
							for (j = 1, current_set = set; arr[current_set] != NULL && j <= 10; current_set++, j++)
							{
								printf("%2d.[%c��]", j, arr[current_set]->item_current_category);
								wprintf(L"%ls%ls", arr[current_set]->item_current_name, arr[current_set]->item_current_level);
								printf("���ӷ֣�%.*lf��\n", GetPrecision(arr[current_set]->item_current_scores), arr[current_set]->item_current_scores);
							}
							if (set >= 10)
							{
								page_up_lock1 = false;
							}
							else
							{
								page_up_lock1 = true;
							}
							if (j > 10 && arr[current_set] != NULL)
							{
								page_down_lock1 = false;
							}
							else
							{
								page_down_lock1 = true;
							}
							int k1 = 0;
							int k2 = 1;
							for (; arr[k1] != NULL; k1++, k2++);
							total_page = k2 / 10 + 1;
							SetConsoleTextAttribute(hConsole, 8);
							printf("\033[26;0H<��%d/%dҳ>", current_page, total_page);
							SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
						}
						else
						{
							printf("��");
						}
					}
				}
				else
				{
					printf("��");
				}
				flag = false;
				TimeDisplay = true;
			}
		}
		/*���̼��*/
		char ch;
		{
			for (;;)
			{
				if (key_is_pressed())
				{
					if ((GetAsyncKeyState(VK_CONTROL) & 0x8000))
					{
						if ((GetAsyncKeyState(81) & 0x8000))
						{
							if (MessageBox(hwnd, _T("��ȷ��Ҫ�˳���"), _T("��ʾ"), MB_YESNO) == IDYES)
							{
								system("cls");
								plink_list_head->access %= 10;
								exit(0);
							}
							else
							{
								ch = '\0';
								break;
							}
						}
					}
					else
					{
						ch = _getch();
						break;
					}
				}
			}
		}

		/*����*/
		if (ch == 27)
		{
			TimeDisplay = false;
			return;
		}
		/*��һҳ*/
		else if (!search_is_on && (ch == 77 || ch == 'd' || ch == 'D') && !page_down_lock)
		{
			for (int k = 10; ptr && k > 0; k--, ptr = ptr->next);
			flag = true;
			current_page++;
			continue;
		}
		/*��һҳ*/
		else if (!search_is_on && (ch == 75 || ch == 'a' || ch == 'A') && !page_up_lock)
		{
			for (int k = 10; ptr && k > 0; k--, ptr = ptr->prev);
			flag = true;
			current_page--;
			continue;
		}
		/*$��һҳ*/
		else if (search_is_on && (ch == 77 || ch == 'd' || ch == 'D') && !page_down_lock1)
		{
			set += 10;
			flag = true;
			current_page++;
			continue;
		}
		/*$��һҳ*/
		else if (search_is_on && (ch == 75 || ch == 'a' || ch == 'A') && !page_up_lock1)
		{
			set -= 10;
			flag = true;
			current_page--;
			continue;
		}
		else if (extra_point_policy_linklist_head_ptr && (ch == '\n' || ch == '\r'))
		{
			memset(arr, 0, sizeof(arr));
			flag = true;
			TimeDisplay = false;
			/*���ع��*/
			{
				CONSOLE_CURSOR_INFO cursorInfo;
				GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
				cursorInfo.bVisible = TRUE;						// ���ù��ɼ���ΪFALSE�����ع��  
				SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
			}

			wprintf(L"\033[7;13H\033[K%ls", search_box);
			fgetws(search_box, sizeof(search_box) / sizeof(search_box[0]), stdin);

			/*���ع��*/
			{
				CONSOLE_CURSOR_INFO cursorInfo;
				GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
				cursorInfo.bVisible = FALSE;						// ���ù��ɼ���ΪFALSE�����ع��  
				SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
			}

			if (search_box[0] == L'\n')
			{
				memset(search_box, 0, sizeof(search_box));
				continue;
			}
			else
			{
				for (int k = 0; search_box[k] != L'\0'; k++)
				{
					if (search_box[k] == L'\n')
					{
						search_box[k] = L'\0';
					}
				}
				temp_ptr = extra_point_policy_linklist_head_ptr;
				for (int k = 0; temp_ptr;)
				{
					if (wcsstr_custom(temp_ptr->item_default_name, search_box))
					{
						arr[k++] = temp_ptr;
						temp_ptr = temp_ptr->next;
					}
					else
					{
						temp_ptr = temp_ptr->next;
					}
				}
				search_is_on = true;
			}
		}
		else if (search_is_on && ch == '\b' && search_box[0] != L'\0')
		{
			memset(search_box, 0, sizeof(search_box));
			//wchar_t* cut_ptr = search_box;
			//for (; !cut_ptr != L'\0'; cut_ptr++);
			//cut_ptr--;
			//*cut_ptr = L'\0';
			search_is_on = false;
			flag = true;
			current_page = 1;
			continue;
		}
	}
}

//�༭�ӷ� ���� ѡ����� ����
void edit_extra_point_policy_selecting_part(void)
{
	int i = 0, j = 1;
	int current_page = 1;
	int total_page = 1;
	struct extra_point_policy* ptemp = NULL;
	struct extra_point_policy* ptr = extra_point_policy_linklist_head_ptr;
	bool flag = true;
	bool page_up_lock = true;
	bool page_down_lock = true;
	item_is_saved = false;
	for (COORD pos = { 0,7 };;)
	{

		/*UI���*/
		{
			TimeDisplay = false;
			if (flag)
			{
				/*UI����*/
				{
					/*���ع��*/
					{
						CONSOLE_CURSOR_INFO cursorInfo;
						GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
						cursorInfo.bVisible = FALSE;						// ���ù��ɼ���ΪFALSE�����ع��  
						SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
					}
					system("cls");
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
					printf("\033[1;1H[ESC] ����  [CTRL+Q] �˳�  [CTRL+S] ����");
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
					draw_division_line();
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
					printf("\033[3;1H��ǰλ�ã��༭�ӷ����߲˵�");
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED);
					printf("\033[5;0H[����/WS] �ƶ���ͷ  [����/AD] ��ҳ");
					printf("\033[6;0H[ENTER] ȷ��ѡ��  [���ּ�] ֱ��ѡ��");
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
				}

				/*�ӷ����ߴ�ӡ*/
				{
					if (item_is_saved)
					{
						build_extra_point_policy_linklist();
						item_is_saved = false;
					}
					if (extra_point_policy_linklist_head_ptr)
					{
						extra_point_policy_linklist_dictionary_ordered_sorting();
						printf("\033[8;0H");
						for (ptemp = ptr, j = 1; ptemp && j <= 10; ptemp = ptemp->next, j++)
						{
							wprintf(L" %2d.[%lc��]%ls%ls���ӷ֣�%.*lf��\n", j, ptemp->item_default_category, ptemp->item_current_name, ptemp->item_current_level, GetPrecision(ptemp->item_current_scores), ptemp->item_current_scores);
						}
						if (ptr->prev)
						{
							page_up_lock = false;
						}
						else
						{
							page_up_lock = true;
						}
						if (j > 10)
						{
							if (ptemp)
								page_down_lock = false;
						}
						else
						{
							page_down_lock = true;
						}
						int k = 1;
						for (struct extra_point_policy* p = extra_point_policy_linklist_head_ptr; p; p = p->next, k++);
						total_page = k / 10 + 1;
						SetConsoleTextAttribute(hConsole, 8);
						printf("\033[26;0H<��%d/%dҳ>", current_page, total_page);
						SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
					}
					else
					{
						printf("\033[8;0H ��");
					}

				}
				flag = false;
			}

		}



		/*��ռ�ͷ*/
		{
			//printf("\033[5;1H ");
			//printf("\033[6;1H ");
			//printf("\033[7;1H ");
			if (extra_point_policy_linklist_head_ptr)
				printf("\033[8;1H ");
			printf("\033[9;1H ");
			printf("\033[10;1H ");
			printf("\033[11;1H ");
			printf("\033[12;1H ");
			printf("\033[13;1H ");
			printf("\033[14;1H ");
			printf("\033[15;1H ");
			printf("\033[16;1H ");
			printf("\033[17;1H ");
			printf("\033[18;1H ");
		}
		/*���ü�ͷ*/
		{
			pos.Y = pos.Y >= 7 ? pos.Y : 7;
			pos.Y = pos.Y <= j + 5 ? pos.Y : j + 5;
			pos.Y = pos.Y == 6 ? 7 : pos.Y;
			SetConsoleCursorPosition(hConsole, pos);
			SetConsoleTextAttribute(hConsole, 14);
			if (extra_point_policy_linklist_head_ptr)
				printf(">");
			SetConsoleTextAttribute(hConsole, 7);
		}
		/*�������*/
		char ch;
		{
			for (;;)
			{
				if (key_is_pressed())
				{
					if ((GetAsyncKeyState(VK_CONTROL) & 0x8000))
					{
						if ((GetAsyncKeyState(83) & 0x8000))
						{
							save_extra_point_policy_linklist();
							int is_ok = MessageBox(NULL, _T("����ɹ�"), _T("��ʾ"), MB_OK);
							while (is_ok != IDOK);
							flag = true;
							ch = '\0';
							initial_proof_with_policy();

							log_file = fopen(LogName, "a");
							fprintf(log_file, "%s  ����Ա ���� ������ӷ���Ŀ\n\n", LogTime);
							fclose(log_file);

							break;
						}
						if ((GetAsyncKeyState(81) & 0x8000))
						{
							if (MessageBox(hwnd, _T("��ȷ��Ҫ�˳���"), _T("��ʾ"), MB_YESNO) == IDYES)
							{
								system("cls");
								plink_list_head->access %= 10;
								exit(0);
							}
							else
							{
								ch = '\0';
								break;
							}
						}
					}
					else
					{
						ch = _getch();
						break;
					}
				}
			}
		}

		if (ch == 72 || ch == 'w' || ch == 'W')
		{
			pos.Y--;
		}
		if (ch == 80 || ch == 's' || ch == 'S')
		{
			pos.Y++;
		}
		if (ch == 27)
		{
			break;
		}
		/*��һҳ*/
		else if ((ch == 77 || ch == 'd' || ch == 'D') && !page_down_lock)
		{
			for (int k = 10; ptr && k > 0; k--, ptr = ptr->next);
			flag = true;
			current_page++;
			continue;
		}
		/*��һҳ*/
		else if ((ch == 75 || ch == 'a' || ch == 'A') && !page_up_lock)
		{
			for (int k = 10; ptr && k > 0; k--, ptr = ptr->prev);
			flag = true;
			current_page--;
			continue;
		}
		if (isdigit(ch))
		{
			ptemp = ptr;
			for (int k = ch - '0' - 1; k > 0 && ptemp; k--, ptemp = ptemp->next);
			if (ptemp)
			{
				edit_extra_point_policy_function_part(ptemp);
				ptr = extra_point_policy_linklist_head_ptr;
				flag = true;
				i = 0, j = 1;
			}
		}
		if (ch == '\r' || ch == '\n')
		{
			ptemp = ptr;
			for (int k = pos.Y - 7; k > 0; k--, ptemp = ptemp->next);
			if (ptemp)
			{
				edit_extra_point_policy_function_part(ptemp);
				flag = true;
			}

		}
	}
	return;
}

//�༭�ӷ� ���� �༭���� ����
void edit_extra_point_policy_function_part(struct extra_point_policy* ptr)
{
	bool flag = true;
	TimeDisplay = false;
	item_is_saved = false;
	for (COORD pos = { 0,6 };;)
	{

		/*UI���*/
		{
			/*UI����*/
			{
				if (flag)
				{
					/*���ع��*/
					{
						CONSOLE_CURSOR_INFO cursorInfo;
						GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
						cursorInfo.bVisible = FALSE;						// ���ù��ɼ���ΪFALSE�����ع��  
						SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
					}
					system("cls");
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
					printf("\033[1;1H[ESC] ����  [CTRL+Q] �˳�  [CTRL+S] ����");
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
					draw_division_line();
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
					printf("\033[3;1H��ǰλ�ã��༭�ӷ����߲˵�");
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED);
					printf("\033[5;0H[����/WS] �ƶ���ͷ  [ENTER] ȷ��ѡ��  [���ּ�] ֱ��ѡ��\n");
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

					printf("\033[7;1H");
					if (ptr->item_current_category == '\0')
						wprintf(L" [1]��Ŀ���ƣ�%ls\n [2]��Ŀ�ȼ���%ls\n [3]��Ŀ���ࣺ\n [4]��Ŀ�ӷ֣�%.*lf", ptr->item_current_name, ptr->item_current_level, GetPrecision(ptr->item_current_scores), ptr->item_current_scores);
					else
						wprintf(L" [1]��Ŀ���ƣ�%ls\n [2]��Ŀ�ȼ���%ls\n [3]��Ŀ���ࣺ%c��\n [4]��Ŀ�ӷ֣�%.*lf", ptr->item_current_name, ptr->item_current_level, ptr->item_current_category, GetPrecision(ptr->item_current_scores), ptr->item_current_scores);

					flag = false;
				}
			}
		}

		/*��ռ�ͷ*/
		{
			//printf("\033[5;1H ");
			//printf("\033[6;1H ");
			printf("\033[7;1H ");
			printf("\033[8;1H ");
			printf("\033[9;1H ");
			printf("\033[10;1H ");
			//printf("\033[11;1H ");
			//printf("\033[12;1H ");
			//printf("\033[13;1H ");
			//printf("\033[14;1H ");
			//printf("\033[16;1H ");
			//printf("\033[17;1H ");
			//printf("\033[18;1H ");
		}
		/*���ü�ͷ*/
		{
			SetConsoleCursorPosition(hConsole, pos);
			SetConsoleTextAttribute(hConsole, 14);
			printf(">");
			SetConsoleTextAttribute(hConsole, 7);
		}

		/*�������*/
		char ch;
		for (;;)
		{
			if (key_is_pressed())
			{
				if ((GetAsyncKeyState(VK_CONTROL) & 0x8000))
				{
					if ((GetAsyncKeyState(81) & 0x8000))				//Q
					{
						if (MessageBox(hwnd, _T("��ȷ��Ҫ�˳���"), _T("��ʾ"), MB_YESNO) == IDYES)
						{
							system("cls");
							plink_list_head->access %= 10;
							exit(0);
						}
						else
						{
							ch = '\0';
							break;
						}
					}
					if ((GetAsyncKeyState(83) & 0x8000))			//S
					{
						flag = true;
						item_is_saved = true;
						ch = '\0';
						wcscpy(ptr->item_default_name, ptr->item_current_name);
						wcscpy(ptr->item_default_level, ptr->item_current_level);
						ptr->item_default_scores = ptr->item_current_scores;
						ptr->item_default_category = ptr->item_current_category;
						save_extra_point_policy_linklist();
						MessageBox(hwnd, _T("����ɹ�"), _T("��ʾ"), MB_OK);
						while (_kbhit())
							_getch();
						initial_proof_with_policy();

						log_file = fopen(LogName, "a");
						fprintf(log_file, "%s  ����Ա ���� ������ӷ���Ŀ\n\n", LogTime);
						fclose(log_file);


						break;
					}

				}
				else
				{
					ch = _getch();
					break;
				}
			}
		}

		if (ch == 72 || ch == 'w' || ch == 'W')
		{
			pos.Y--;
			pos.Y = pos.Y >= 6 ? pos.Y : 6;
		}
		if (ch == 80 || ch == 's' || ch == 'S')
		{
			pos.Y++;
			pos.Y = pos.Y <= 9 ? pos.Y : 9;
		}
		if (ch == 27)
		{
			ptr->item_current_scores = ptr->item_default_scores;
			return;
		}
		if (ch == '\r' || ch == '\n' || isdigit(ch))
		{
			if (isdigit(ch))
				pos.Y = 5 + ch - '0';
			if (pos.Y == 6 || ch == '1')
			{
				for (;;)
				{
					/*��ʾ���*/
					{
						CONSOLE_CURSOR_INFO cursorInfo;
						GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
						cursorInfo.bVisible = TRUE;						// ���ù��ɼ���ΪFALSE�����ع��  
						SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
					}
					printf("\033[7;15H\033[K");

					log_file = fopen(LogName, "a");
					fprintf(log_file, "%s  ����Ա �޸� ������ӷ���Ŀ���� ", LogTime);
					fwprintf(log_file, L"%ls->", ptr->item_default_name);

					wchar_t buffer[20] = { 0 };

					fgetws(buffer, sizeof(buffer) / sizeof(buffer[0]), stdin);

					if (buffer[0] == '\n')
					{
						flag = true;
						break;
					}
					else
					{
						for (wchar_t* ptr = buffer; *ptr != L'\0'; ptr++)
						{
							if (*ptr == L'\n')
								*ptr = '\0';
						}
					}
					memset(ptr->item_current_name, 0, sizeof(ptr->item_current_name));
					wcscpy(ptr->item_current_name, buffer);

					fwprintf(log_file, L"%ls\n\n", ptr->item_current_name);
					fclose(log_file);

					flag = true;
					/*���ع��*/
					{
						CONSOLE_CURSOR_INFO cursorInfo;
						GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
						cursorInfo.bVisible = FALSE;						// ���ù��ɼ���ΪFALSE�����ع��  
						SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
					}


					break;
				}
			}
			else if (pos.Y == 7 || ch == '2')
			{
				for (;;)
				{
					/*��ʾ���*/
					{
						CONSOLE_CURSOR_INFO cursorInfo;
						GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
						cursorInfo.bVisible = TRUE;						// ���ù��ɼ���ΪFALSE�����ع��  
						SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
					}
					printf("\033[8;15H\033[K");

					log_file = fopen(LogName, "a");
					fprintf(log_file, "%s  ����Ա �޸� ������ӷ���Ŀ�ȼ� ", LogTime);
					fwprintf(log_file, L"%ls->", ptr->item_default_level);

					wscanf(L"%ls", ptr->item_current_level); getchar();

					fwprintf(log_file, L"%ls\n\n", ptr->item_current_level);
					fclose(log_file);

					if (!islegal(NULL, ptr->item_current_level, NULL, 2))
					{
						printf("\033[7;15H\033[K���벻�Ϲ�");
						getchar();
						/*���ع��*/
						{
							CONSOLE_CURSOR_INFO cursorInfo;
							GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
							cursorInfo.bVisible = FALSE;						// ���ù��ɼ���ΪFALSE�����ع��  
							SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
						}

						continue;
					}
					else
					{
						flag = true;
						/*���ع��*/
						{
							CONSOLE_CURSOR_INFO cursorInfo;
							GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
							cursorInfo.bVisible = FALSE;						// ���ù��ɼ���ΪFALSE�����ع��  
							SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
						}

						break;
					}
				}
			}
			else if (pos.Y == 8 || ch == '3')
			{
				for (;;)
				{
					/*��ʾ���*/
					{
						CONSOLE_CURSOR_INFO cursorInfo;
						GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
						cursorInfo.bVisible = TRUE;						// ���ù��ɼ���ΪFALSE�����ع��  
						SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
					}
					printf("\033[9;15H\033[K");
					char str[20] = { 0 };
					char c = ptr->item_current_category;
					fgets(str, sizeof(str) / sizeof(str[0]), stdin);
					ptr->item_current_category = str[0];
					if (!isalpha(ptr->item_current_category))
					{
						printf("\033[9;15H\033[K���벻�Ϲ�");
						getchar();
						/*���ع��*/
						{
							CONSOLE_CURSOR_INFO cursorInfo;
							GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
							cursorInfo.bVisible = FALSE;						// ���ù��ɼ���ΪFALSE�����ع��  
							SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
						}

						continue;
					}
					else
					{
						flag = true;
						/*���ع��*/
						{
							CONSOLE_CURSOR_INFO cursorInfo;
							GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
							cursorInfo.bVisible = FALSE;						// ���ù��ɼ���ΪFALSE�����ع��  
							SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
						}

						log_file = fopen(LogName, "a");
						fprintf(log_file, "%s  ����Ա �޸� ������ӷ���Ŀ���� %c->%c\n\n", LogTime, c, str[0]);
						fclose(log_file);


						break;
					}
				}
			}
			else if (pos.Y == 9 || ch == '4')
			{
				/*��ʾ���*/
				{
					CONSOLE_CURSOR_INFO cursorInfo;
					GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
					cursorInfo.bVisible = TRUE;						// ���ù��ɼ���ΪFALSE�����ع��  
					SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
				}
				printf("\033[10;15H\033[K");
				double temp = ptr->item_current_scores;

				double number = 0;
				char numberStr[100] = { 0 };
				for (;;)
				{
					fgets(numberStr, sizeof(numberStr), stdin);


					if (numberStr[0] == '\n' || numberStr[0] == '\r')
					{
						flag = true;
						break;

					}
					else
					{
						for (char* p = numberStr; *p != '\0'; p++)
						{
							if (*p == '\n')
								*p = '\0';
						}
					}


					// �Ƴ����з��Ϳ��ܵ������հ��ַ�  
					char* endptr;
					endptr = numberStr + strcspn(numberStr, "\n");
					if (*endptr) *endptr = '\0'; // ����ҵ����з������滻Ϊ�ַ���������  

					// ���Խ��ַ���ת��Ϊdouble  
					number = strtod(numberStr, &endptr);

					// ���ת���Ƿ�ɹ��������ַ���ֻ�������ֺ�С����  
					if (endptr == numberStr || !isdigit((unsigned char)*numberStr))
					{
						printf("\033[10;15H\033[K��������ȷ�ķ���");
						getchar(); // �ȴ��û�������������뻺����  
						printf("\033[10;15H\033[K"); // �����ʾ��Ϣ  
						memset(numberStr, 0, sizeof(numberStr));
						continue;
					}

					// ��������Ƿ���0��100֮�䣨����0��100��  
					if (number < 0 || number > 100)
					{
						printf("\033[10;15H\033[K������0��100֮��ķ���");
						getchar(); // �ȴ��û�������������뻺����  
						printf("\033[10;15H\033[K"); // �����ʾ��Ϣ  
						memset(numberStr, 0, sizeof(numberStr));
						continue;
					}

					// ���һ�����������ñ�־���˳�ѭ��  
					flag = true;
					break;
				}

				/*��ʾ���*/
				{
					CONSOLE_CURSOR_INFO cursorInfo;
					GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
					cursorInfo.bVisible = FALSE;						// ���ù��ɼ���ΪFALSE�����ع��  
					SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
				}


				ptr->item_current_scores = number;

				log_file = fopen(LogName, "a");
				fprintf(log_file, "%s  ����Ա �޸� ������ӷ���Ŀ�ӷ�ֵ %lf->%lf\n\n", LogTime, temp, number);
				fclose(log_file);


			}
		}
	}
	return;
}


//��׼�ӷ�֤�� ѡ����� ����
void approve_extra_point_proof_selecting_part(void)
{
	struct extra_point_proof* head_ptr = NULL;
	head_ptr = _build_extra_point_proof_linklist(head_ptr);
	struct extra_point_proof* ptr = head_ptr;
	struct extra_point_proof* temp_ptr = NULL;
	int i = 1;
	bool flag = true;
	bool page_up_lock = true;
	bool page_down_lock = true;
	item_is_deleted = false;
	item_is_saved = false;

	for (COORD pos = { 0,7 };;)
	{
		/*UI���*/
		{
			/*UI����*/
			{
				if (flag)
				{
					TimeDisplay = false;
					system("cls");
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
					printf("\033[1;1H[ESC] ����  [CTRL+Q] �˳�  [CTRL+S] ����");
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
					draw_division_line();
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
					printf("\033[3;1H��ǰλ�ã�������ӷ���Ŀ��˲˵�");
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED);
					printf("\033[5;0H[����/WS] �ƶ���ͷ  [����/AD] ��ҳ\n[ENTER] ȷ��ѡ��  [���ּ�] ֱ��ѡ��\n");
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
				}
				/*���ع��*/
				{
					hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
					CONSOLE_CURSOR_INFO cursorInfo;
					GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
					cursorInfo.bVisible = FALSE;						// ���ù��ɼ���ΪFALSE�����ع��  
					SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
				}
				flag = false;
			}

			/*��ӡ*/
			{
				if (item_is_saved)
				{
					_build_extra_point_proof_linklist(head_ptr);
					ptr = head_ptr;
					item_is_saved = false;
				}

				if (item_is_deleted)
				{
					ptr = head_ptr;
					item_is_deleted = false;
				}

				printf("\033[8;0H");

				if (head_ptr)
				{
					for (i = 1, temp_ptr = ptr; i <= 10 && temp_ptr; i++, temp_ptr = temp_ptr->next)
					{
						if (temp_ptr->proof_is_true)
						{
							SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN);
							printf(" ������֤��");
						}
						else
						{
							SetConsoleTextAttribute(hConsole, FOREGROUND_RED);
							printf(" ��δ��֤��");
						}
						SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
						printf("%2d.ѧ�ţ�%-9s", i, temp_ptr->applicant_account);
						wprintf(L"��Ŀ���ƣ�%ls\n", temp_ptr->item_name);
					}
					if (ptr->prev)
					{
						page_up_lock = false;
					}
					else
					{
						page_up_lock = true;
					}
					if (i > 10)
					{
						temp_ptr = ptr;
						for (int k = 10; k > 0; k--, temp_ptr = temp_ptr->next);
						if (temp_ptr)
							page_down_lock = false;
					}
					else
					{
						page_down_lock = true;
					}

				}
				else
				{
					printf("��");
				}
			}

		}

		/*��ռ�ͷ*/
		{
			//printf("\033[5;1H ");
			//printf("\033[6;1H ");
			//printf("\033[7;1H ");
			if (head_ptr)
			{
				printf("\033[8;1H ");
			}
			printf("\033[9;1H ");
			printf("\033[10;1H ");
			printf("\033[11;1H ");
			printf("\033[12;1H ");
			printf("\033[13;1H ");
			printf("\033[14;1H ");
			printf("\033[16;1H ");
			printf("\033[17;1H ");
			printf("\033[18;1H ");
		}

		/*���ü�ͷ*/
		{
			pos.Y = pos.Y >= 7 ? pos.Y : 7;
			pos.Y = pos.Y <= i + 5 ? pos.Y : i + 5;
			SetConsoleCursorPosition(hConsole, pos);
			SetConsoleTextAttribute(hConsole, 14);
			if (head_ptr)
			{
				printf(">");
			}
			SetConsoleTextAttribute(hConsole, 7);
		}

		/*���̼��*/
		char ch;
		{
			for (;;)
			{
				if (key_is_pressed())
				{
					if ((GetAsyncKeyState(VK_CONTROL) & 0x8000))
					{
						if ((GetAsyncKeyState(83) & 0x8000))			//S
						{
							flag = true;
							item_is_saved = true;
							ch = '\0';
							save_extra_point_proof_linklist(head_ptr);
							MessageBox(hwnd, _T("����ɹ�"), _T("��ʾ"), MB_OK);
							while (_kbhit())
								_getch();

							log_file = fopen(LogName, "a");
							fprintf(log_file, "%s  ����Ա ���� ������ӷ���Ŀ\n\n", LogTime);
							fclose(log_file);

							break;
						}
						if ((GetAsyncKeyState(81) & 0x8000))				//Q
						{
							if (MessageBox(hwnd, _T("��ȷ��Ҫ�˳���"), _T("��ʾ"), MB_YESNO) == IDYES)
							{
								system("cls");
								plink_list_head->access %= 10;
								exit(0);
							}
							else
							{
								ch = '\0';
								break;
							}
						}
					}
					else
					{
						ch = _getch();
						break;
					}
				}
			}
		}

		if (ch == 72 || ch == 'w' || ch == 'W')
		{
			pos.Y--;
		}
		else if (ch == 80 || ch == 's' || ch == 'S')
		{
			pos.Y++;
		}
		else if (ch == 27)
		{
			return;
		}
		/*��һҳ*/
		else if ((ch == 77 || ch == 'd' || ch == 'D') && !page_down_lock)
		{
			for (int k = 10; ptr && k > 0; k--, ptr = ptr->next);
			flag = true;
			continue;
		}
		/*��һҳ*/
		else if ((ch == 75 || ch == 'a' || ch == 'A') && !page_up_lock)
		{
			for (int k = 10; ptr && k > 0; k--, ptr = ptr->prev);
			flag = true;
			continue;
		}
		else if (isdigit(ch))
		{
			temp_ptr = head_ptr;
			for (int k = ch - '0' - 1; k > 0 && temp_ptr; k--, temp_ptr = temp_ptr->next);
			if (temp_ptr)
			{
				head_ptr = approve_extra_point_proof_function_part(temp_ptr, head_ptr);
				flag = true;
			}
		}
		else if (ch == '\r' || ch == '\n')
		{
			temp_ptr = head_ptr;
			for (int k = pos.Y - 7; k > 0; k--, temp_ptr = temp_ptr->next);
			if (temp_ptr)
			{
				head_ptr = approve_extra_point_proof_function_part(temp_ptr, head_ptr);
				flag = true;
			}

		}
	}

}


//��׼�ӷ�֤�� �༭���� ����
struct extra_point_proof* approve_extra_point_proof_function_part(struct extra_point_proof* object_ptr, struct extra_point_proof* head_ptr)
{
	bool flag = true;
	bool flag1 = true;
	bool flag2 = true;
	system("cls");

	for (;;)
	{
		/*UI���*/
		{
			/*UI����*/
			{
				TimeDisplay = false;
				if (flag)
				{
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
					printf("\033[1;1H[ESC] ����  [CTRL+Q] �˳�  [CTRL+S] ���� ");
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
					draw_division_line();
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
					printf("\033[3;1H��ǰλ�ã�������ӷ���Ŀ��˲˵�");
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED);
					printf("\033[5;0H[ENTER] �޸���֤״̬  [BACKSPACE] ɾ������");
					SetConsoleTextAttribute(hConsole, 14);
					printf("\033[15;0H���� [SPACE] �鿴֤������");
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

				}
				/*���ع��*/
				{
					hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
					CONSOLE_CURSOR_INFO cursorInfo;
					GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
					cursorInfo.bVisible = FALSE;						// ���ù��ɼ���ΪFALSE�����ع��  
					SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
				}
				flag = false;
				TimeDisplay = true;
			}

			/*��ӡ*/
			{
				TimeDisplay = false;
				if (flag1)
				{
					printf("\033[7;0H");

					if (object_ptr)
					{
						if (flag2)
						{
							printf("ѧ�ţ�%-8s\n", object_ptr->applicant_account);
							wprintf(L"��Ŀ���ƣ�%ls\n��Ŀ�ȼ���%ls\n", object_ptr->item_name, object_ptr->item_level);
							printf("��Ŀ�ӷ�ֵ��%.*lf\n", GetPrecision(object_ptr->item_scores), object_ptr->item_scores);
							printf("״̬��");
							flag2 = false;
						}
						if (object_ptr->proof_is_true)
						{
							SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN);
							printf("\033[11;7H����֤");
						}
						else
						{
							SetConsoleTextAttribute(hConsole, FOREGROUND_RED);
							printf("\033[11;7Hδ��֤");
						}
						SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
						if (*(object_ptr->file_location) != '\0')
						{
							wchar_t temp_file[1024] = { 0 };
							wcscpy(temp_file, object_ptr->file_location);
							wchar_t* cut_ptr = wcsrchr(temp_file, L'/');
							wchar_t* start_ptr = cut_ptr + 1;
							for (; *cut_ptr != '.'; cut_ptr++);
							*cut_ptr = L'\0';
							wprintf(L"\033[14;1H֤�����ϣ�%ls", start_ptr);
						}
						else
						{
							printf("\033[14;1H֤�����ϣ���");
						}

					}
					flag1 = false;
				}
				TimeDisplay = true;
			}
		}

		/*���̼��*/
		char ch;
		{
			for (;;)
			{
				if (key_is_pressed())
				{
					if ((GetAsyncKeyState(VK_CONTROL) & 0x8000))
					{
						if ((GetAsyncKeyState(81) & 0x8000))				//Q
						{
							if (MessageBox(hwnd, _T("��ȷ��Ҫ�˳���"), _T("��ʾ"), MB_YESNO) == IDYES)
							{
								system("cls");
								plink_list_head->access %= 10;
								exit(0);
							}
							else
							{
								ch = '\0';
								break;
							}
						}
						if ((GetAsyncKeyState(83) & 0x8000))			//S
						{
							flag = true;
							item_is_saved = true;
							ch = '\0';
							save_extra_point_proof_linklist(head_ptr);
							MessageBox(hwnd, _T("����ɹ�"), _T("��ʾ"), MB_OK);
							while (_kbhit())
								_getch();

							log_file = fopen(LogName, "a");
							fprintf(log_file, "%s  ����Ա ���� ������ӷ�����\n\n", LogTime);
							fclose(log_file);


							break;
						}
					}
					else
					{
						ch = _getch();
						break;
					}
				}
			}
		}

		if (ch == '\b')
		{
			struct extra_point_proof* object_prev = object_ptr->prev;
			struct extra_point_proof* object_next = object_ptr->next;
			if (object_prev && object_next)
			{
				object_prev->next = object_next;
				object_next->prev = object_prev;

				log_file = fopen(LogName, "a");
				fprintf(log_file, "%s  ����Ա ɾ�� %s ������ӷ�����\n\n", LogTime, object_ptr->applicant_account);
				fclose(log_file);

				free(object_ptr);
			}
			else if (object_prev && !object_next)
			{
				object_prev->next = NULL;

				log_file = fopen(LogName, "a");
				fprintf(log_file, "%s  ����Ա ɾ�� %s ������ӷ�����\n\n", LogTime, object_ptr->applicant_account);
				fclose(log_file);


				free(object_ptr);
			}
			else if (!object_prev && object_next)
			{
				head_ptr = object_next;
				object_next->prev = NULL;

				log_file = fopen(LogName, "a");
				fprintf(log_file, "%s  ����Ա ɾ�� %s ������ӷ�����\n\n", LogTime, object_ptr->applicant_account);
				fclose(log_file);

				free(object_ptr);
			}
			else if (!object_prev && !object_next)
			{
				head_ptr = NULL;

				log_file = fopen(LogName, "a");
				fprintf(log_file, "%s  ����Ա ɾ�� %s ������ӷ�����\n\n", LogTime, object_ptr->applicant_account);
				fclose(log_file);

				free(object_ptr);
			}
			object_ptr = NULL;
			item_is_deleted = true;
			break;
		}
		else if (ch == '\r' || ch == '\n')
		{
			object_ptr->proof_is_true = !object_ptr->proof_is_true;

			log_file = fopen(LogName, "a");
			fprintf(log_file, "%s  ����Ա �޸� %s ������ӷ�������֤״̬\n\n", LogTime, object_ptr->applicant_account);
			fclose(log_file);

			flag1 = true;
		}
		else if (ch == 27)
		{
			break;
		}
		else if (ch == ' ')
		{
			char mb_path[MAX_PATH]; // ����·�����ᳬ��MAX_PATH����  
			size_t len = wcstombs(NULL, object_ptr->file_location, 0); // ��ȡת������Ҫ���ֽ���  

			if (len == (size_t)-1) {
				perror("wcstombsʧ��");
			}

			if (wcstombs(mb_path, object_ptr->file_location, len + 1) == (size_t)-1) { // +1 for null terminator  
				perror("wcstombsʧ��");
			}

			//����Ҫִ�е������ַ���  
			char command[MAX_PATH * 2]; // ȷ�������ַ������㹻�Ŀռ�  
			//snprintf(command, sizeof(command), "start winword.exe \"%s\"", mb_path);
			sprintf(command, "start \"\" \"%s\"", mb_path); // ���������ַ���  
			// ʹ��system����ִ������  
			int _result = system(command);

			if (_result == -1) {
				perror("system����ʧ��");
			}

		}
	}
	return head_ptr;
}

//�ύ�ӷ�����
void submit_extra_point_application(void)
{
	TimeDisplay = false;
	bool flag = true;
	bool item_is_added = false;
	struct extra_point_proof* ptr = (struct extra_point_proof*)malloc(sizeof(struct extra_point_proof));
	_initial_extra_point_proof(ptr);

	for (COORD pos = { 0,11 };;)
	{
		/*UI���*/
		{
			/*UI����*/
			{
				if (flag)
				{
					system("cls");
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
					printf("\033[1;1H[ESC] ����  [CTRL+Q] �˳�  [CTRL+S] �ύ");
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
					draw_division_line();
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
					printf("\033[3;1H��ǰλ�ã�����������ӷ���Ŀ�˵�");
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED);
					printf("\033[5;0H[����/WS] �ƶ���ͷ  [ENTER] ȷ��ѡ��  [���ּ�] ֱ��ѡ��\n");
					SetConsoleTextAttribute(hConsole, 8);
					printf("\033[7;0H(����ʾ��)\nѧ�ţ�12345678\n��Ŀ���ƣ�ȫ����ѧ����ѧ����\n��Ŀ�ȼ������Ҽ�һ�Ƚ�");
					SetConsoleTextAttribute(hConsole, 14);
					printf("\033[17;0H [CTRL+A] ����֤������");
					SetConsoleTextAttribute(hConsole, 7);
					/*��ӡ���߱���*/
					{
						if (item_is_added)
						{
							ptr = (struct extra_point_proof*)malloc(sizeof(struct extra_point_proof));
							_initial_extra_point_proof(ptr);
							item_is_added = false;
						}
						//if (ptr->item_category == '\0' && ptr->item_scores == 0)
						//	wprintf(L" \033[13;0H [1]��Ŀ���ƣ�%ls\n [2]��Ŀ�ȼ���%ls", ptr->item_name, ptr->item_level);
						//else if (ptr->item_category == '\0' && !ptr->item_scores == 0)
						//	wprintf(L" \033[13;0H [1]��Ŀ���ƣ�%ls\n [2]��Ŀ�ȼ���%ls", ptr->item_name, ptr->item_level);
						//else
						printf("\033[12;0H [1]ѧ�ţ�%s\n", ptr->applicant_account);
						wprintf(L" [2]��Ŀ���ƣ�%ls\n [3]��Ŀ�ȼ���%ls", ptr->item_name, ptr->item_level);
					}
					flag = false;
				}
				/*���ع��*/
				{
					hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
					CONSOLE_CURSOR_INFO cursorInfo;
					GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
					cursorInfo.bVisible = FALSE;						// ���ù��ɼ���ΪFALSE�����ع��  
					SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
				}

			}
		}

		/*��ռ�ͷ*/
		{
			//printf("\033[5;1H ");
			//printf("\033[6;1H ");
			//printf("\033[7;1H ");
			//printf("\033[8;1H ");
			//printf("\033[9;1H ");
			//printf("\033[10;1H ");
			//printf("\033[11;1H ");
			printf("\033[12;1H ");
			printf("\033[13;1H ");
			printf("\033[14;1H ");
			//printf("\033[15;1H ");
			//printf("\033[16;1H ");
			//printf("\033[17;1H ");
			//printf("\033[18;1H ");
		}
		/*���ü�ͷ*/
		{
			SetConsoleCursorPosition(hConsole, pos);
			SetConsoleTextAttribute(hConsole, 14);
			printf(">");
			SetConsoleTextAttribute(hConsole, 7);
		}

		/*���̼��*/
		char ch;
		{
			for (;;)
			{
				if (key_is_pressed())
				{
					if ((GetAsyncKeyState(VK_CONTROL) & 0x8000))
					{
						if ((GetAsyncKeyState(83) & 0x8000))			//S
						{
							item_is_added = true;
							flag = true;
							ch = '\0';
							FILE* pf = fopen("./extra_point_related/extra_point_proof.txt", "ab");
							fwrite(ptr, sizeof(struct extra_point_proof), 1, pf);
							fclose(pf);
							MessageBox(hwnd, _T("�ύ�ɹ�"), _T("��ʾ"), MB_OK);
							while (_kbhit())
								_getch();
							break;
						}
						if ((GetAsyncKeyState(81) & 0x8000))				//Q
						{
							if (MessageBox(hwnd, _T("��ȷ��Ҫ�˳���"), _T("��ʾ"), MB_YESNO) == IDYES)
							{
								system("cls");
								plink_list_head->access %= 10;
								exit(0);
							}
							else
							{
								ch = '\0';
								break;
							}
						}
						if ((GetAsyncKeyState(65) & 0x8000))				//A
						{
							wchar_t file_name[1024] = { 0 };
							wchar_t input_file_location[1024] = { 0 };
							wchar_t output_file_location[1024] = { 0 };
							wchar_t* p = NULL;
							printf("\033[19;1H�������ļ���\n");
							fgetws(input_file_location, sizeof(input_file_location) / sizeof(input_file_location[0]), stdin);
							for (p = input_file_location; *p != L'\n' && *p != L'\0' && p; p++);
							*p = L'\0';
							const wchar_t* lastSlash = wcsrchr(input_file_location, L'\\');  // �������һ����б��  
							if (lastSlash != NULL) {
								wcscpy(file_name, lastSlash + 1);  // ����б��֮��Ĳ��ָ��Ƶ�filename  
							}
							else {
								wcscpy(file_name, input_file_location);  // ���û�з�б�ܣ���ô����path�����ļ���  
							}
							wcscpy(output_file_location, L"./extra_point_related/file/");
							wcscat(output_file_location, file_name);

							wcscpy(ptr->file_location, output_file_location);


							char mb_path1[MAX_PATH]; // ����·�����ᳬ��MAX_PATH����  
							char mb_path2[MAX_PATH]; // ����·�����ᳬ��MAX_PATH����  
							size_t len1 = wcstombs(NULL, output_file_location, 0); // ��ȡת������Ҫ���ֽ���  
							size_t len2 = wcstombs(NULL, output_file_location, 0); // ��ȡת������Ҫ���ֽ���  

							if (len1 == (size_t)-1) {
								perror("wcstombsʧ��");
							}
							if (len2 == (size_t)-1) {
								perror("wcstombsʧ��");
							}

							if (wcstombs(mb_path1, output_file_location, len1 + 1) == (size_t)-1) { // +1 for null terminator  
								perror("wcstombsʧ��");
							}
							if (wcstombs(mb_path2, input_file_location, len2 + 1) == (size_t)-1) { // +1 for null terminator  
								perror("wcstombsʧ��");
							}

							bool result = CopyFile(mb_path2, mb_path1, FALSE);
							if (result)
							{
								MessageBox(hwnd, _T("�ϴ��ɹ�"), _T("��ʾ"), MB_OK);
							}
							else
							{
								MessageBox(hwnd, _T("�ϴ�ʧ��"), _T("��ʾ"), MB_OK);
								memset(ptr->file_location, 0, sizeof(ptr->file_location));
								printf("\033[20;1H\033[K");
							}


							//char mb_path[MAX_PATH]; // ����·�����ᳬ��MAX_PATH����  
							//size_t len = wcstombs(NULL, output_file_location, 0); // ��ȡת������Ҫ���ֽ���  

							//if (len == (size_t)-1) {
							//	perror("wcstombsʧ��");
							//}

							//if (wcstombs(mb_path, output_file_location, len + 1) == (size_t)-1) { // +1 for null terminator  
							//	perror("wcstombsʧ��");
							//}


							////����Ҫִ�е������ַ���  
							//char command[MAX_PATH * 2]; // ȷ�������ַ������㹻�Ŀռ�  
							//snprintf(command, sizeof(command), "start winword.exe \"%s\"", mb_path);
							//// ʹ��system����ִ������  
							//int _result = system(command);

							//if (_result == -1) {
							//	perror("system����ʧ��");
							//}
						}
					}
					else
					{
						ch = _getch();
						break;
					}
				}
			}
		}

		/*ѡ�񲿷�*/
		{
			if (ch == 72 || ch == 'w' || ch == 'W')
			{
				pos.Y--;
				pos.Y = pos.Y >= 11 ? pos.Y : 11;
			}
			else if (ch == 80 || ch == 's' || ch == 'S')
			{
				pos.Y++;
				pos.Y = pos.Y <= 13 ? pos.Y : 13;
			}
			else if (ch == 27)
			{
				return;
			}
			else if (ch == '\r' || ch == '\n' || isdigit(ch))
			{
				if (pos.Y == 11 || ch == '1')												//ѧ��
				{
					/*��ʾ���*/
					{
						hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
						CONSOLE_CURSOR_INFO cursorInfo;
						GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
						cursorInfo.bVisible = TRUE;							// ���ù��ɼ���ΪFALSE�����ع��  
						SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
					}
					/*���������������*/
					{
						printf("\033[12;1H ");
						printf("\033[13;1H ");
						printf("\033[14;1H ");
						printf("\033[12;11H\033[K");
					}
					memset(ptr->applicant_account, 0, sizeof(ptr->applicant_account));
					scanf("%s", ptr->applicant_account); getchar();
					if (!islegal(NULL, NULL, ptr->applicant_account, 3))
					{
						memset(ptr->applicant_account, 0, sizeof(ptr->applicant_account));
						printf("\033[12;11H\033[K");
					}
					flag = true;
					/*���ع��*/
					{
						hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
						CONSOLE_CURSOR_INFO cursorInfo;
						GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
						cursorInfo.bVisible = FALSE;							// ���ù��ɼ���ΪFALSE�����ع��  
						SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
					}
				}
				else if (pos.Y == 12 || ch == '2')
				{
					/*��ʾ���*/
					{
						hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
						CONSOLE_CURSOR_INFO cursorInfo;
						GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
						cursorInfo.bVisible = TRUE;							// ���ù��ɼ���ΪFALSE�����ع��  
						SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
					}
					/*���������������*/
					{
						printf("\033[12;1H ");
						printf("\033[13;1H ");
						printf("\033[14;1H ");
						printf("\033[13;15H\033[K");
					}

					memset(ptr->item_name, 0, sizeof(ptr->item_name));
					wscanf(L"%ls", ptr->item_name); getchar();				//��Ŀ����
					if (!islegal(NULL, ptr->item_name, NULL, 2))
					{
						memset(ptr->item_name, 0, sizeof(ptr->item_name));
						printf("\033[13;15H\033[K");
					}

					flag = true;
					/*���ع��*/
					{
						hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
						CONSOLE_CURSOR_INFO cursorInfo;
						GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
						cursorInfo.bVisible = FALSE;							// ���ù��ɼ���ΪFALSE�����ع��  
						SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
					}

				}

				else if (pos.Y == 13 || ch == '3')
				{
					/*��ʾ���*/
					{
						hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
						CONSOLE_CURSOR_INFO cursorInfo;
						GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
						cursorInfo.bVisible = TRUE;							// ���ù��ɼ���ΪFALSE�����ع��  
						SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
					}
					/*���������������*/
					{
						printf("\033[12;1H ");
						printf("\033[13;1H ");
						printf("\033[14;1H ");
						printf("\033[14;15H\033[K");
					}

					memset(ptr->item_level, 0, sizeof(ptr->item_level));
					wscanf(L"%ls", ptr->item_level); getchar();				//��Ŀ�ȼ�
					if (!islegal(NULL, ptr->item_level, NULL, 2))
					{
						memset(ptr->item_level, 0, sizeof(ptr->item_level));
						printf("\033[14;15H\033[K");
					}

					flag = true;
					/*���ع��*/
					{
						hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
						CONSOLE_CURSOR_INFO cursorInfo;
						GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
						cursorInfo.bVisible = FALSE;							// ���ù��ɼ���ΪFALSE�����ع��  
						SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
					}

				}
			}

		}
	}


}


//���Ӽӷ� ���� ����
void add_extra_point_policy_linklist(void)
{
	bool flag = true;
	bool item_is_added = false;
	TimeDisplay = false;
	struct extra_point_policy* ptr = (struct extra_point_policy*)malloc(sizeof(struct extra_point_policy));
	initial_extra_point_policy(ptr);

	for (COORD pos = { 0,12 };;)
	{
		/*UI���*/
		{
			/*UI����*/
			{
				if (flag)
				{
					system("cls");
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
					printf("\033[1;1H[ESC] ����  [CTRL+Q] �˳�  [CTRL+A] ׷�� ");
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
					draw_division_line();
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
					//printf("\033[3;1H��ǰλ�ã�����������ӷ���Ŀ�˵�");
					printf("\033[3;1H��ǰλ�ã�����������ӷ���Ŀ�˵�");
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED);
					printf("\033[5;0H[����/WS] �ƶ���ͷ  [ENTER] ȷ��ѡ��  [���ּ�] ֱ��ѡ��\n");
					SetConsoleTextAttribute(hConsole, 8);
					printf("\033[7;0H(����ʾ��)\n[1]��Ŀ���ƣ�ȫ����ѧ����ѧ����\n[2]��Ŀ�ȼ������Ҽ�һ�Ƚ�\n[3]��Ŀ���ࣺB\n[4]��Ŀ�ӷ֣�0.2");
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
					/*���ع��*/
					{
						hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
						CONSOLE_CURSOR_INFO cursorInfo;
						GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
						cursorInfo.bVisible = FALSE;						// ���ù��ɼ���ΪFALSE�����ع��  
						SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
					}
					/*��ӡ���߱���*/
					{
						if (item_is_added)
						{
							ptr = (struct extra_point_policy*)malloc(sizeof(struct extra_point_policy));
							initial_extra_point_policy(ptr);
							item_is_added = false;
						}
						if (ptr->item_default_category == '\0' && ptr->item_default_scores == 0)
							wprintf(L" \033[13;0H [1]��Ŀ���ƣ�%ls\n [2]��Ŀ�ȼ���%ls\n [3]��Ŀ���ࣺ\n [4]��Ŀ�ӷ֣�", ptr->item_default_name, ptr->item_default_level);
						else if (ptr->item_default_category == '\0' && !ptr->item_default_scores == 0)
							wprintf(L" \033[13;0H [1]��Ŀ���ƣ�%ls\n [2]��Ŀ�ȼ���%ls\n [3]��Ŀ���ࣺ\n [4]��Ŀ�ӷ֣�%.*lf", ptr->item_default_name, ptr->item_default_level, GetPrecision(ptr->item_default_scores), ptr->item_default_scores);
						else if (ptr->item_default_scores == 0 && !ptr->item_default_category == '\0')
							wprintf(L" \033[13;0H [1]��Ŀ���ƣ�%ls\n [2]��Ŀ�ȼ���%ls\n [3]��Ŀ���ࣺ%c��\n [4]��Ŀ�ӷ֣�", ptr->item_default_name, ptr->item_default_level, ptr->item_default_category);
						else
							wprintf(L" \033[13;0H [1]��Ŀ���ƣ�%ls\n [2]��Ŀ�ȼ���%ls\n [3]��Ŀ���ࣺ%c��\n [4]��Ŀ�ӷ֣�%.*lf", ptr->item_default_name, ptr->item_default_level, ptr->item_default_category, GetPrecision(ptr->item_default_scores), ptr->item_default_scores);
					}
					flag = false;
				}
			}
		}

		/*��ռ�ͷ*/
		{
			//printf("\033[5;1H ");
			//printf("\033[6;1H ");
			//printf("\033[7;1H ");
			//printf("\033[8;1H ");
			//printf("\033[9;1H ");
			//printf("\033[10;1H ");
			//printf("\033[11;1H ");
			//printf("\033[12;1H ");
			printf("\033[13;1H ");
			printf("\033[14;1H ");
			printf("\033[15;1H ");
			printf("\033[16;1H ");
			//printf("\033[17;1H ");
			//printf("\033[18;1H ");
		}
		/*���ü�ͷ*/
		{
			SetConsoleCursorPosition(hConsole, pos);
			SetConsoleTextAttribute(hConsole, 14);
			printf(">");
			SetConsoleTextAttribute(hConsole, 7);
		}

		/*���̼��*/
		char ch;
		{
			for (;;)
			{
				if (key_is_pressed())
				{
					if ((GetAsyncKeyState(VK_CONTROL) & 0x8000))
					{
						if ((GetAsyncKeyState(81) & 0x8000))				//Q
						{
							if (MessageBox(hwnd, _T("��ȷ��Ҫ�˳���"), _T("��ʾ"), MB_YESNO) == IDYES)
							{
								system("cls");
								plink_list_head->access %= 10;
								exit(0);
							}

							else
							{
								ch = '\0';
								break;
							}
						}
						if ((GetAsyncKeyState(65) & 0x8000))				//A
						{
							if (extra_point_policy_linklist_head_ptr)
							{
								wcscpy(ptr->item_current_name, ptr->item_default_name);
								wcscpy(ptr->item_current_level, ptr->item_default_level);
								ptr->item_current_category = ptr->item_default_category;
								ptr->item_current_scores = ptr->item_default_scores;

								struct extra_point_policy* temp_ptr = extra_point_policy_linklist_head_ptr;
								for (; temp_ptr->next; temp_ptr = temp_ptr->next);
								temp_ptr->next = ptr;
								ptr->next = NULL;
								ptr->prev = temp_ptr;
							}
							else
							{
								wcscpy(ptr->item_current_name, ptr->item_default_name);
								wcscpy(ptr->item_current_level, ptr->item_default_level);
								ptr->item_current_category = ptr->item_default_category;
								ptr->item_current_scores = ptr->item_default_scores;

								ptr->next = NULL;
								ptr->prev = NULL;
								extra_point_policy_linklist_head_ptr = ptr;
							}
							MessageBox(NULL, _T("׷�ӳɹ�"), _T("��ʾ"), MB_OK);
							while (_kbhit())
								_getch();

							log_file = fopen(LogName, "a");
							fprintf(log_file, "%s  ����Ա ׷�� ������ӷ���Ŀ ", LogTime);
							fwprintf(log_file, L"%ls%ls\n\n", ptr->item_current_name, ptr->item_current_level);
							fclose(log_file);

							ptr = (struct extra_point_policy*)malloc(sizeof(struct extra_point_policy));
							initial_extra_point_policy(ptr);
							flag = true;
							item_is_added = true;
							ch = '\0';
							break;
						}
					}
					else
					{
						ch = _getch();
						break;
					}
				}
			}
		}

		/*ѡ�񲿷�*/
		{
			if (ch == 72 || ch == 'w' || ch == 'W')
			{
				pos.Y--;
				pos.Y = pos.Y >= 12 ? pos.Y : 12;
			}
			if (ch == 80 || ch == 's' || ch == 'S')
			{
				pos.Y++;
				pos.Y = pos.Y <= 15 ? pos.Y : 15;
			}
			if (ch == 27)
			{
				free(ptr);
				return;
			}
			if (ch == '\r' || ch == '\n' || isdigit(ch))
			{

				if (pos.Y == 15 || ch == '4')
				{
					pos.Y = 15;
					/*��ʾ���*/
					{
						hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
						CONSOLE_CURSOR_INFO cursorInfo;
						GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
						cursorInfo.bVisible = TRUE;							// ���ù��ɼ���ΪFALSE�����ع��  
						SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
					}
					/*���������������*/
					{
						printf("\033[13;1H ");
						printf("\033[14;1H ");
						printf("\033[15;1H ");
						printf("\033[16;1H ");
						printf("\033[16;15H\033[K");
					}

					double number = 0;
					char numberStr[100] = { 0 };
					for (;;)
					{
						fgets(numberStr, sizeof(numberStr), stdin);


						if (numberStr[0] == '\n' || numberStr[0] == '\r')
						{
							flag = true;
							break;

						}
						else
						{
							for (char* p = numberStr; *p != '\0'; p++)
							{
								if (*p == '\n')
									*p = '\0';
							}
						}


						// �Ƴ����з��Ϳ��ܵ������հ��ַ�  
						char* endptr;
						endptr = numberStr + strcspn(numberStr, "\n");
						if (*endptr) *endptr = '\0'; // ����ҵ����з������滻Ϊ�ַ���������  

						// ���Խ��ַ���ת��Ϊdouble  
						number = strtod(numberStr, &endptr);

						// ���ת���Ƿ�ɹ��������ַ���ֻ�������ֺ�С����  
						if (endptr == numberStr || !isdigit((unsigned char)*numberStr))
						{
							printf("\033[16;15H\033[K��������ȷ�ķ���");
							getchar(); // �ȴ��û�������������뻺����  
							printf("\033[16;15H\033[K"); // �����ʾ��Ϣ  
							printf("\033[16;15H\033[K"); // �����ʾ��Ϣ  
							memset(numberStr, 0, sizeof(numberStr));
							continue;
						}

						// ��������Ƿ���0��100֮�䣨����0��100��  
						if (number < 0 || number > 100)
						{
							printf("\033[16;15H\033[K������0��100֮��ķ���");
							getchar(); // �ȴ��û�������������뻺����  
							printf("\033[16;15H\033[K"); // �����ʾ��Ϣ  
							memset(numberStr, 0, sizeof(numberStr));
							continue;
						}

						// ���һ�����������ñ�־���˳�ѭ��  
						flag = true;
						break;
					}

					ptr->item_default_scores = number;

				}
				else if (pos.Y == 14 || ch == '3')
				{
					for (;;)
					{
						pos.Y = 14;

						/*��ʾ���*/
						{
							hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
							CONSOLE_CURSOR_INFO cursorInfo;
							GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
							cursorInfo.bVisible = TRUE;							// ���ù��ɼ���ΪFALSE�����ع��  
							SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
						}
						/*���������������*/
						{
							printf("\033[13;1H ");
							printf("\033[14;1H ");
							printf("\033[15;1H ");
							printf("\033[16;1H ");
							printf("\033[15;15H\033[K");
						}
						char str[20] = { 0 };
						fgets(str, sizeof(str) / sizeof(str[0]), stdin);
						ptr->item_default_category = str[0];			//��Ŀ���
						if (!isalpha(ptr->item_default_category))
						{
							ptr->item_default_category = '\0';
							printf("\033[15;15H\033[K������Ӣ����ĸ");
							getchar();
							printf("\033[15;15H\033[K");
							continue;
						}
						else
						{
							flag = true;
							break;
						}

					}
				}
				else if (pos.Y == 13 || ch == '2')
				{

					for (;;)
					{
						pos.Y = 13;

						/*��ʾ���*/
						{
							hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
							CONSOLE_CURSOR_INFO cursorInfo;
							GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
							cursorInfo.bVisible = TRUE;							// ���ù��ɼ���ΪFALSE�����ع��  
							SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
						}
						/*���������������*/
						{
							printf("\033[13;1H ");
							printf("\033[14;1H ");
							printf("\033[15;1H ");
							printf("\033[16;1H ");
							printf("\033[14;15H\033[K");
						}

						memset(ptr->item_default_level, 0, sizeof(ptr->item_default_level));
						wscanf(L"%ls", ptr->item_default_level); getwchar();				//��Ŀ�ȼ�
						if (!islegal(NULL, ptr->item_default_level, NULL, 2))
						{
							memset(ptr->item_default_level, 0, sizeof(ptr->item_default_level));
							printf("\033[14;15H\033[K�������ݲ��Ϲ�");
							getchar();
							printf("\033[14;15H\033[K");
							continue;
						}
						else
						{
							flag = true;
							break;
						}
					}

				}
				else if (pos.Y == 12 || ch == '1')
				{

					for (;;)
					{
						pos.Y = 12;

						/*��ʾ���*/
						{
							hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
							CONSOLE_CURSOR_INFO cursorInfo;
							GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
							cursorInfo.bVisible = TRUE;							// ���ù��ɼ���ΪFALSE�����ع��  
							SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
						}
						/*���������������*/
						{
							printf("\033[13;1H ");
							printf("\033[14;1H ");
							printf("\033[15;1H ");
							printf("\033[16;1H ");
							printf("\033[13;15H\033[K");
						}

						memset(ptr->item_default_name, 0, sizeof(ptr->item_default_name));
						wscanf(L"%ls", ptr->item_default_name); getwchar();				//��Ŀ����
						flag = true;
						break;

					}
				}
			}

		}
	}

	return;
}

//ɾ���ӷ� ���� ����
void delet_extra_point_policy_linklist(void)
{
	int current_page = 1;
	int total_page = 1;
	int i = 0, j = 1;
	struct extra_point_policy* ptr = extra_point_policy_linklist_head_ptr;
	struct extra_point_policy* temp_ptr = NULL;
	bool flag = true;
	bool not_empty = true;
	bool page_up_lock = true;
	bool page_down_lock = true;
	bool item_is_deleted = false;

	for (COORD pos = { 0,7 };;)
	{

		/*UI���*/
		{
			TimeDisplay = false;
			if (flag)
			{
				/*UI����*/
				{
					system("cls");
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
					printf("\033[1;1H[ESC] ����  [CTRL+Q] �˳�  [CTRL+S] ����");
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
					draw_division_line();
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
					printf("\033[3;1H��ǰλ�ã�ɾ���ӷ����߲˵�");
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED);
					printf("\033[5;0H[����/WS] �ƶ���ͷ  [����/AD] ��ҳ");
					printf("\033[6;0H[ENTER] ȷ��ѡ��  [���ּ�] ֱ��ѡ��");
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
				}

				/*�ӷ����ߴ�ӡ*/
				{
					if (item_is_deleted)
					{
						ptr = extra_point_policy_linklist_head_ptr;
						item_is_deleted = false;
					}
					if (extra_point_policy_linklist_head_ptr)
					{
						extra_point_policy_linklist_dictionary_ordered_sorting();
						printf("\033[8;0H");
						for (temp_ptr = ptr, j = 1, i = 0; temp_ptr && j <= 10; temp_ptr = temp_ptr->next, i++, j++)
						{
							printf(" %d.[%lc��]", j, temp_ptr->item_default_category);
							wprintf(L"%ls%ls", temp_ptr->item_default_name, temp_ptr->item_default_level);
							wprintf(L"���ӷ֣�%.*lf��\n", GetPrecision(temp_ptr->item_default_scores), temp_ptr->item_default_scores);
						}
						not_empty = true;
						if (ptr->prev)
						{
							page_up_lock = false;
						}
						else
						{
							page_up_lock = true;
						}
						if (j > 10)
						{
							if (temp_ptr)
								page_down_lock = false;
						}
						else
						{
							page_down_lock = true;
						}
					}
					else
					{
						printf("\033[8;0H��");
						not_empty = false;
					}
					int k = 1;
					for (struct extra_point_policy* p = extra_point_policy_linklist_head_ptr; p; p = p->next, k++);
					total_page = k / 10 + 1;
					SetConsoleTextAttribute(hConsole, 8);
					printf("\033[26;0H<��%d/%dҳ>", current_page, total_page);
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
				}
				flag = false;
			}

		}

		/*��ռ�ͷ*/
		{
			//printf("\033[5;1H ");
			//printf("\033[6;1H ");
			//printf("\033[7;1H ");
			printf("\033[8;1H ");
			printf("\033[9;1H ");
			printf("\033[10;1H ");
			printf("\033[11;1H ");
			printf("\033[12;1H ");
			printf("\033[13;1H ");
			printf("\033[14;1H ");
			printf("\033[15;1H ");
			printf("\033[16;1H ");
			printf("\033[17;1H ");
			printf("\033[18;1H ");
		}
		/*���ü�ͷ*/
		{
			pos.Y = pos.Y >= 7 ? pos.Y : 7;
			pos.Y = pos.Y <= j + 5 ? pos.Y : j + 5;
			pos.Y = pos.Y == 6 ? 7 : pos.Y;
			if (not_empty)
			{
				SetConsoleCursorPosition(hConsole, pos);
			}
			SetConsoleTextAttribute(hConsole, 14);
			if (not_empty)
				printf(">");
			SetConsoleTextAttribute(hConsole, 7);
		}

		/*�������*/
		char ch;
		{
			for (;;)
			{
				if (key_is_pressed())
				{
					if ((GetAsyncKeyState(VK_CONTROL) & 0x8000))
					{
						if ((GetAsyncKeyState(83) & 0x8000))
						{
							save_extra_point_policy_linklist();
							int is_ok = MessageBox(NULL, _T("����ɹ�"), _T("��ʾ"), MB_OK);
							while (is_ok != IDOK);
							flag = true;
							ch = '\0';

							log_file = fopen(LogName, "a");
							fprintf(log_file, "%s  ����Ա ���� ������ӷ���Ŀ\n\n", LogTime);
							fclose(log_file);

							break;
						}
						if ((GetAsyncKeyState(81) & 0x8000))
						{
							if (MessageBox(hwnd, _T("��ȷ��Ҫ�˳���"), _T("��ʾ"), MB_YESNO) == IDYES)
							{
								system("cls");
								plink_list_head->access %= 10;
								exit(0);
							}
							else
							{
								ch = '\0';
								break;
							}
						}
					}
					else
					{
						ch = _getch();
						break;
					}
				}
			}
		}

		/*ѡ�񲿷�*/
		{
			if (ch == 72 || ch == 'w' || ch == 'W')
			{
				pos.Y--;
			}
			if (ch == 80 || ch == 's' || ch == 'S')
			{
				pos.Y++;
			}
			if (ch == 27)
			{
				break;
			}
			/*��һҳ*/
			if ((ch == 77 || ch == 'd' || ch == 'D') && !page_down_lock)
			{
				for (int k = 10; ptr && k > 0; k--, ptr = ptr->next);
				flag = true;
				current_page++;
				continue;
			}
			/*��һҳ*/
			if ((ch == 75 || ch == 'a' || ch == 'A') && !page_up_lock)
			{
				for (int k = 10; ptr && k > 0; k--, ptr = ptr->prev);
				flag = true;
				current_page--;
				continue;
			}
			if (isdigit(ch))
			{
				ptr = extra_point_policy_linklist_head_ptr;
				for (int k = ch - '0' - 1; k > 0 && ptr; k--, ptr = ptr->next);
				if (ptr)
				{
					struct extra_point_policy* ptr_prev = ptr->prev;
					struct extra_point_policy* ptr_next = ptr->next;
					if (!ptr_prev && ptr_next)
					{
						extra_point_policy_linklist_head_ptr = ptr_next;
						ptr_next->prev = NULL;

						log_file = fopen(LogName, "a");
						fprintf(log_file, "%s  ����Ա ɾ�� ������ӷ���Ŀ ", LogTime);
						fwprintf(log_file, L"%ls%ls\n\n", ptr->item_current_name, ptr->item_current_level);
						fclose(log_file);


						free(ptr);
					}
					else if (!ptr_next && ptr_prev)
					{
						ptr_prev->next = NULL;

						log_file = fopen(LogName, "a");
						fprintf(log_file, "%s  ����Ա ɾ�� ������ӷ���Ŀ ", LogTime);
						fwprintf(log_file, L"%ls%ls\n\n", ptr->item_current_name, ptr->item_current_level);
						fclose(log_file);

						free(ptr);
					}
					else if (!ptr_next && !ptr_prev)
					{
						extra_point_policy_linklist_head_ptr = NULL;

						log_file = fopen(LogName, "a");
						fprintf(log_file, "%s  ����Ա ɾ�� ������ӷ���Ŀ ", LogTime);
						fwprintf(log_file, L"%ls%ls\n\n", ptr->item_current_name, ptr->item_current_level);
						fclose(log_file);

						free(ptr);
					}
					else
					{
						ptr_prev->next = ptr_next;
						ptr_next->prev = ptr_prev;

						log_file = fopen(LogName, "a");
						fprintf(log_file, "%s  ����Ա ɾ�� ������ӷ���Ŀ ", LogTime);
						fwprintf(log_file, L"%ls%ls\n\n", ptr->item_current_name, ptr->item_current_level);
						fclose(log_file);

						free(ptr);
					}
					int is_ok = -1;
					is_ok = MessageBox(NULL, _T("ɾ���ɹ�"), _T("��ʾ"), MB_OK);
					while (is_ok != IDOK);
					flag = true;
					item_is_deleted = true;
					i = 0, j = 1;
				}
				else
				{
					MessageBox(NULL, _T("ɾ��ʧ�ܣ�����Ŀ"), _T("��ʾ"), MB_OK);
				}
			}
			if (ch == '\r' || ch == '\n')
			{
				ptr = extra_point_policy_linklist_head_ptr;
				for (int k = pos.Y - 7; k > 0; k--, ptr = ptr->next);
				if (ptr)
				{
					struct extra_point_policy* ptr_prev = ptr->prev;
					struct extra_point_policy* ptr_next = ptr->next;
					if (!ptr_prev && ptr_next)
					{
						extra_point_policy_linklist_head_ptr = ptr_next;
						ptr_next->prev = NULL;

						log_file = fopen(LogName, "a");
						fprintf(log_file, "%s  ����Ա ɾ�� ������ӷ���Ŀ ", LogTime);
						fwprintf(log_file, L"%ls%ls\n\n", ptr->item_current_name, ptr->item_current_level);
						fclose(log_file);

						free(ptr);
					}
					else if (!ptr_next && ptr_prev)
					{
						ptr_prev->next = NULL;

						log_file = fopen(LogName, "a");
						fprintf(log_file, "%s  ����Ա ɾ�� ������ӷ���Ŀ ", LogTime);
						fwprintf(log_file, L"%ls%ls\n\n", ptr->item_current_name, ptr->item_current_level);
						fclose(log_file);

						free(ptr);
					}
					else if (!ptr_next && !ptr_prev)
					{
						extra_point_policy_linklist_head_ptr = NULL;

						log_file = fopen(LogName, "a");
						fprintf(log_file, "%s  ����Ա ɾ�� ������ӷ���Ŀ ", LogTime);
						fwprintf(log_file, L"%ls%ls\n\n", ptr->item_current_name, ptr->item_current_level);
						fclose(log_file);

						free(ptr);
					}
					else
					{
						ptr_prev->next = ptr_next;
						ptr_next->prev = ptr_prev;

						log_file = fopen(LogName, "a");
						fprintf(log_file, "%s  ����Ա ɾ�� ������ӷ���Ŀ ", LogTime);
						fwprintf(log_file, L"%ls%ls\n\n", ptr->item_current_name, ptr->item_current_level);
						fclose(log_file);

						free(ptr);
					}
					MessageBox(NULL, _T("ɾ���ɹ�"), _T("��ʾ"), MB_OK);
					while (_kbhit())
						_getch();
					flag = true;
					item_is_deleted = true;
				}
				else
				{
					MessageBox(NULL, _T("ɾ��ʧ�ܣ�����Ŀ"), _T("��ʾ"), MB_OK);
				}

			}
		}
	}
	return;

}


//��ʼ���ӷ�����
void initial_extra_point_policy(struct extra_point_policy* ptr)
{
	ptr->item_default_category = '\0';
	ptr->item_current_category = '\0';
	ptr->item_current_scores = ptr->item_default_scores = 0;
	memset(ptr->item_default_level, 0, sizeof(ptr->item_default_level));
	memset(ptr->item_current_level, 0, sizeof(ptr->item_current_level));
	memset(ptr->item_default_name, 0, sizeof(ptr->item_default_name));
	memset(ptr->item_current_name, 0, sizeof(ptr->item_current_name));
	ptr->next = ptr->prev = NULL;
	return;
}


//����ӷ� ���� ����
void build_extra_point_policy_linklist(void)
{
	FILE* pf = fopen("./extra_point_related/extra_point_policy.txt", "rb");
	if (!pf)
	{
		pf = fopen("./extra_point_related/extra_point_policy.txt", "wb");
		fclose(pf);
		pf = fopen("./extra_point_related/extra_point_policy.txt", "rb");
	}

	struct extra_point_policy* ptr1 = (struct extra_point_policy*)malloc(sizeof(struct extra_point_policy));
	struct extra_point_policy* ptr2 = (struct extra_point_policy*)malloc(sizeof(struct extra_point_policy));
	extra_point_policy_linklist_head_ptr = ptr1;
	if (fread(ptr1, sizeof(struct extra_point_policy), 1, pf))
	{
		for (ptr1->prev = NULL; fread(ptr2, sizeof(struct extra_point_policy), 1, pf); ptr2 = (struct extra_point_policy*)malloc(sizeof(struct extra_point_policy)))
		{
			wcscpy(ptr1->item_current_name, ptr1->item_default_name);
			wcscpy(ptr1->item_current_level, ptr1->item_default_level);
			ptr1->item_current_category = ptr1->item_default_category;
			ptr1->item_current_scores = ptr1->item_default_scores;

			ptr1->next = ptr2;
			ptr2->prev = ptr1;
			ptr1 = ptr1->next;
		}
		free(ptr2);
		ptr1->next = NULL;
	}
	else
	{
		extra_point_policy_linklist_head_ptr = NULL;
	}
	fclose(pf);
	return;
}



//����ӷ� ���� ����
void save_extra_point_policy_linklist(void)
{
	FILE* pf = fopen("./extra_point_related/extra_point_policy.txt", "wb");
	for (struct extra_point_policy* ptr = extra_point_policy_linklist_head_ptr; ptr && fwrite(ptr, sizeof(struct extra_point_policy), 1, pf); ptr = ptr->next);
	fclose(pf);
	return;
}

//����ӷ� ֤�� ����
void save_extra_point_proof_linklist(struct extra_point_proof* head_ptr)
{
	FILE* pf = fopen("./extra_point_related/extra_point_proof.txt", "wb");
	for (struct extra_point_proof* ptr = head_ptr; ptr && fwrite(ptr, sizeof(struct extra_point_proof), 1, pf); ptr = ptr->next);
	fclose(pf);
	return;
}

//�����ֵ�������  
void extra_point_policy_linklist_dictionary_ordered_sorting(void)
{
	bool flag = true;
	struct extra_point_policy* ptr1;				//ptr2��ǰ���ڵ�
	struct extra_point_policy* ptr2;				//�������Ľڵ�
	struct extra_point_policy* ptr3;				//�������Ľڵ�
	struct extra_point_policy* ptr4;				//ptr4�ĺ����ڵ�
	struct extra_point_policy* temp_ptr = NULL;		//ptr4�ĺ����ڵ�

	/*ֻ��һ��*/
	ptr1 = extra_point_policy_linklist_head_ptr;
	if (!ptr1 || !ptr1->next)
	{
		return;
	}

	/*����Ŀ������*/
	{
		for (flag = true; flag; )
		{
			for (flag = false, ptr2 = extra_point_policy_linklist_head_ptr, ptr3 = ptr2->next; ptr3; ptr2 = ptr2->next, ptr3 = ptr3->next)
			{
				if (ptr2->item_default_category > ptr3->item_default_category)
				{
					ptr1 = ptr2->prev;
					ptr4 = ptr3->next;

					ptr3->next = ptr2;
					ptr2->next = ptr4;

					if (ptr1)
					{
						ptr1->next = ptr3;
					}
					else
					{
						extra_point_policy_linklist_head_ptr = ptr3;
					}
					if (ptr4)
					{
						ptr4->prev = ptr2;
					}
					else
					{
						ptr2->next = NULL;
					}
					ptr3->prev = ptr1;
					ptr2->prev = ptr3;

					temp_ptr = ptr2;
					ptr2 = ptr3;
					ptr3 = temp_ptr;
					flag = true;
				}
			}
		}
	}

	/*����Ŀ���Ʒ���*/
	{
		for (flag = true; flag; )
		{
			for (flag = false, ptr2 = extra_point_policy_linklist_head_ptr, ptr3 = ptr2->next; ptr3; ptr2 = ptr2->next, ptr3 = ptr3->next)
			{
				if (wcscmp(ptr2->item_default_name, ptr3->item_default_name) > 0 && ptr2->item_default_category == ptr3->item_default_category)
				{
					ptr1 = ptr2->prev;
					ptr4 = ptr3->next;

					ptr3->next = ptr2;
					ptr2->next = ptr4;

					if (ptr1)
					{
						ptr1->next = ptr3;
					}
					else
					{
						extra_point_policy_linklist_head_ptr = ptr3;
					}
					if (ptr4)
					{
						ptr4->prev = ptr2;
					}
					else
					{
						ptr2->next = NULL;
					}
					ptr3->prev = ptr1;
					ptr2->prev = ptr3;

					temp_ptr = ptr2;
					ptr2 = ptr3;
					ptr3 = temp_ptr;
					flag = true;
				}
			}
		}
	}

	/*����Ŀ��������*/
	{
		for (flag = true; flag; )
		{
			for (flag = false, ptr2 = extra_point_policy_linklist_head_ptr, ptr3 = ptr2->next; ptr3; ptr2 = ptr2->next, ptr3 = ptr3->next)
			{
				if (ptr2->item_current_scores < ptr3->item_current_scores && ptr2->item_default_category == ptr3->item_default_category && !wcscmp(ptr2->item_default_name, ptr3->item_default_name))
				{
					ptr1 = ptr2->prev;
					ptr4 = ptr3->next;

					ptr3->next = ptr2;
					ptr2->next = ptr4;

					if (ptr1)
					{
						ptr1->next = ptr3;
					}
					else
					{
						extra_point_policy_linklist_head_ptr = ptr3;
					}
					if (ptr4)
					{
						ptr4->prev = ptr2;
					}
					else
					{
						ptr2->next = NULL;
					}
					ptr3->prev = ptr1;
					ptr2->prev = ptr3;

					temp_ptr = ptr2;
					ptr2 = ptr3;
					ptr3 = temp_ptr;
					flag = true;
				}
			}
		}
	}

	return;

}


//����ӷ� ֤�� ����
void build_extra_point_proof_linklist(void)
{
	FILE* pf = fopen("./extra_point_related/extra_point_proof.txt", "rb");
	if (!pf)
	{
		pf = fopen("./extra_point_related/extra_point_proof.txt", "wb");
		fclose(pf);
		pf = fopen("./extra_point_related/extra_point_proof.txt", "rb");
	}
	struct extra_point_proof* phead = (struct extra_point_proof*)malloc(sizeof(struct extra_point_proof));
	struct extra_point_proof* ptemp = phead;
	struct extra_point_proof* pnewnode = NULL;
	for (size_t i = 0;;)
	{
		pnewnode = (struct extra_point_proof*)malloc(sizeof(struct extra_point_proof));
		i = fread(pnewnode, sizeof(struct extra_point_proof), 1, pf);
		if (i == 0)
			break;
		if (pnewnode->proof_is_true && !strcmp(pnewnode->applicant_account, plink_list_head->account))
			ptemp->next = pnewnode;
		else
		{
			free(pnewnode);
			continue;
		}
		ptemp = ptemp->next;
	}
	ptemp->next = NULL;
	plink_list_head->extra_point_proof_plinklist_head = phead->next;
	free(phead);
	return;
}

//������Ա������ӷ� ֤�� ����
struct extra_point_proof* _build_extra_point_proof_linklist(struct extra_point_proof* head_ptr)
{
	FILE* pf = fopen("./extra_point_related/extra_point_proof.txt", "rb");
	if (!pf)
	{
		pf = fopen("./extra_point_related/extra_point_proof.txt", "wb");
		fclose(pf);
		pf = fopen("./extra_point_related/extra_point_proof.txt", "rb");
	}
	struct extra_point_proof* ptr1 = (struct extra_point_proof*)malloc(sizeof(struct extra_point_proof));
	struct extra_point_proof* ptr2 = (struct extra_point_proof*)malloc(sizeof(struct extra_point_proof));
	head_ptr = ptr1;
	if (fread(ptr1, sizeof(struct extra_point_proof), 1, pf))
	{
		for (ptr1->prev = NULL; fread(ptr2, sizeof(struct extra_point_proof), 1, pf); ptr2 = (struct extra_point_proof*)malloc(sizeof(struct extra_point_proof)))
		{
			ptr1->next = ptr2;
			ptr2->prev = ptr1;
			ptr1 = ptr1->next;
		}
		free(ptr2);
		ptr1->next = NULL;
	}
	else
	{
		head_ptr = NULL;
	}
	fclose(pf);
	return head_ptr;
}


////�����ӷ�֤��
//void add_extra_point_proof(void)
//{
//	FILE* pf = fopen("extra_point_proof.txt", "wb");
//	if (!pf)
//	{
//		printf("��ʧ��");
//		getchar();
//	}
//	struct extra_point_proof test;
//	struct extra_point_proof test1;
//	struct extra_point_proof* ptest=&test;
//	strcpy(test.account, "55230214");
//	wcscpy(test.item_name, L"ȫ����ѧ����ѧ����");
//	wcscpy(test.item_level, L"���Ҽ�һ�Ƚ�");
//	strcpy(test1.account, "55230214");
//	wcscpy(test1.item_name, L"ȫ����ѧ����ѧ����");
//	wcscpy(test1.item_level, L"���Ҽ����Ƚ�");
//	test.next = NULL;
//	test.prev = NULL;
//	test.item_scores = 0;
//	test1.next = NULL;
//	test1.prev = NULL;
//	test1.item_scores = 0;
//	fwrite(ptest, sizeof(struct extra_point_proof), 1, pf);
//	ptest = &test1;
//	fwrite(ptest, sizeof(struct extra_point_proof), 1, pf);
//	fclose(pf);
//	return;
//}

//��ֵ�ӷ�֤��
void initial_extra_point_proof(struct extra_point_proof* extra_point_proof_linklist_head_ptr)
{
	for (struct extra_point_proof* proof_ptr = extra_point_proof_linklist_head_ptr; proof_ptr; proof_ptr = proof_ptr->next)
	{
		for (struct extra_point_policy* policy_ptr = extra_point_policy_linklist_head_ptr; policy_ptr; policy_ptr = policy_ptr->next)
		{
			if (!wcscmp(proof_ptr->item_name, policy_ptr->item_default_name) && !wcscmp(proof_ptr->item_level, policy_ptr->item_default_level))
			{
				proof_ptr->item_scores = policy_ptr->item_default_scores;
				break;
			}
		}
	}
	return;
}


//��ʼ���ӷ�֤��
void _initial_extra_point_proof(struct extra_point_proof* ptr)
{
	if (ptr != NULL) {
		ptr->item_scores = 0.0;
		memset(ptr->applicant_account, 0, sizeof(ptr->applicant_account));
		memset(ptr->item_name, 0, sizeof(ptr->item_name));
		memset(ptr->item_level, 0, sizeof(ptr->item_level));
		memset(ptr->file_location, 0, sizeof(ptr->file_location));
		//wmemset(ptr->file_location, '\0', sizeof(ptr->file_location));

		ptr->item_category = '\0';
		ptr->proof_is_true = false;
		ptr->prev = NULL;
		ptr->next = NULL;
	}
}


//��ѯ�ӷ�֤��
void view_extra_point_proof(void)
{
	struct extra_point_proof* ptemp = plink_list_head->extra_point_proof_plinklist_head;
	for (;;)
	{
		/*UI���*/
		{
			system("cls");
			SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
			printf("[ESC] ����");
			SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
			draw_division_line();
			SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
			printf("\033[3;1H��ǰλ�ã��ӷ���Ŀ���ӷ�ֵ�˵�");
			SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
			printf("\033[5;0H");
		}
		if (ptemp)
		{
			for (int i = 1; ptemp; ptemp = ptemp->next)
			{
				wprintf(L"%2d.%ls%ls���ӷ֣�%.2lf��\n", i++, ptemp->item_name, ptemp->item_level, ptemp->item_scores);
			}
			char ch = _getch();
			if (ch == 27)
				return;
			if (ch == 'q')
			{
				system("cls");
				printf("ȷ���˳���\nY/N");
				for (;;)
				{
					ch = _getch();
					if (ch == 'y' || ch == 'Y')
					{
						plink_list_head->access %= 10;
						system("cls");
						exit(0);
					}
					else if (ch == 'n' || ch == 'N')
						break;
					else
						continue;
				}
			}
		}
		else
		{
			printf("��");
			char ch = _getch();
			if (ch == 27)
				return;
			if (ch == 'q')
			{
				system("cls");
				printf("ȷ���˳���\nY/N");
				for (;;)
				{
					char ch = _getch();
					if (ch == 'y' || ch == 'Y')
					{
						plink_list_head->access %= 10;
						system("cls");
						exit(0);
					}
					else if (ch == 'n' || ch == 'N')
						break;
					else
						continue;
				}
			}
		}
	}
	return;
}


#endif

