//��Ҫ�����ˣ�������������S
#ifndef USER_MENU_H
#define USER_MENU_H
////////
#include"struct.h"
#include"recommend_exempt.h"
#include"header_and_tool.h"		
#include"information_related.h"	
#include"scores_reports_related.h"	

void student_menu(void);
void adm_teacher_menu(struct Node_Teacher*);
void teacher_menu(struct Node_Teacher*);
void view_scores_report(void);
void initial_student(struct user*);
void config_menu(void);

//�û��˵�
void user_menu(void)
{
	if(plink_list_head->access%10==0)
	strcpy(stunumglobal, plink_list_head->account);
	bool flag = true;
	for (char buffer[20];;)
	{
		//memset(stunumglobal, 0, sizeof(stunumglobal));
		//memcpy(stunumglobal,plink_list_head->account,sizeof(plink_list_head->account));

		if (!extra_point_policy_linklist_head_ptr)
		{
			build_extra_point_policy_linklist();
			extra_point_policy_linklist_dictionary_ordered_sorting();
			initial_proof_with_policy();
		}

		/*ѧ���˵�*/
		if (plink_list_head->access % 10 == 0)
		{
			build_extra_point_proof_linklist();
			student_menu();
			return;
		}

		/*����Ա�˵�*/
		else if (plink_list_head->access % 10 == 2)
		{
			for (;;)
			{
				/*UI���*/
				{
					/*UI����*/
					{
						if (flag)
						{
							system("cls");
							SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
							printf("[ESC] ����");
							SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
							draw_division_line();
							SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
							printf("\033[3;1H��ǰλ�ã��û��˵�");
							SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
							printf("\033[8;0H[1] ��ѯ���˻�����Ϣ\n[2] ����ѧ����Ϣ\n[3] ������ʦ��Ϣ\n[4] �߼�����");
							wprintf(L"\033[5;0H��ӭ����%ls��", plink_list_head->name);
							SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED);
							printf("\033[7;0H���°���ִ�в���");
							SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
							flag = false;
						}
					}
					/*���ع��*/
					{
						HANDLE hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
						CONSOLE_CURSOR_INFO cursorInfo;
						GetConsoleCursorInfo(hStdout, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
						cursorInfo.bVisible = FALSE;					// ���ù��ɼ���ΪFALSE�����ع��  
						SetConsoleCursorInfo(hStdout, &cursorInfo);		// Ӧ���µĹ����Ϣ
					}
					TimeDisplay = true;
				}
				char n = _getch();
				if (n == 27||n=='0')		//����
					return;
				else if (n == 'q')	//�˳�
				{
					system("cls");
					plink_list_head->access %= 10;
					exit(0);
				}
				else if (n == '1')	//��ѯ���˻�����Ϣ
				{
					system("cls");
					TimeDisplay = false;
					struct Node_Administrator* head_adm = (struct Node_Administrator*)malloc(sizeof(struct Node_Administrator));
					head_adm->next = NULL;
					printf("��ѡ���ܣ�\n");
					printf("1.�鿴������Ϣ\n");
					printf("2.�޸Ĺ���Ա������Ϣ\n");
					scanf("%d", &g_choice);
					if (g_choice == 1) {
						print_adm_information(head_adm);
					}
					if (g_choice == 2) {
						modify_adm_information(head_adm);
					}
					printf("\n");
					flag = true;

				}
				else if (n == '2')	//��ѯѧ����Ϣ
				{
					adm_view_scores_report();
					flag = true;
					continue;
				}
				else if (n == '3')	//��ѯ��ʦ��Ϣ
				{
					struct Node_Teacher* head_tea = (struct Node_Teacher*)malloc(sizeof(struct Node_Teacher));
					head_tea->next = NULL;
					adm_teacher_menu(head_tea);
					flag = true;
				}
				else if (n == '4')	//�޸����ò˵�
				{
					config_menu();
					flag = true;
				}



			}
		}

		/*��ʦ�˵�*/
		else if (plink_list_head->access % 10 == 1)
		{
			struct Node_Teacher* head_tea = (struct Node_Teacher*)malloc(sizeof(struct Node_Teacher));
			head_tea->next = NULL;
			search_teacher_information(head_tea);

			head_tea = (struct Node_Teacher*)malloc(sizeof(struct Node_Teacher));
			head_tea->next = NULL;
			teacher_menu(head_tea);
			return;
		}

	}
	return;
}


void student_menu(void)
{
	build_extra_point_proof_linklist();
	bool flag = true;
	for (;;)
	{
		TimeDisplay = false;
		//add_extra_point_policy_linklist();
		//add_extra_point_proof();
		//build_extra_point_proof_linklist();
		//initial_extra_point_proof(plink_list_head->extra_point_proof_plinklist_head);
		//calculate_scores(plink_list_head);

		/*UI���*/
		{
			/*UI����*/
			{
				if (flag)
				{
					system("cls");
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
					printf("[ESC] ����");
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
					draw_division_line();
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
					printf("\033[3;1H��ǰλ�ã��û��˵�");
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
					//printf("\033[8;0H[1] ��ѯ���˻�����Ϣ\n[2] ��ѯ�ɼ���Ϣ\n[3] �鿴��ǰƽ������\n[4] ��ѯ���������Ϣ\n");
					int t1 = load_software_student(head_software);
					int t2 = load_physics_student(head_physics);
					int t3 = load_computer_student(head_computer);
					int t4 = load_math_student(head_math);
					if (t1) {
						g_p = find_software_student_by_stunum(head_software);
						if (g_p != NULL) {
							student_temp = g_p;
						}
					}
					if (t2) {
						g_p = find_physics_student_by_stunum(head_physics);
						if (g_p != NULL) {
							student_temp = g_p;
						}
					}
					if (t3) {
						g_p = find_computer_student_by_stunum(head_computer);
						if (g_p != NULL) {
							student_temp = g_p;
						}
					}
					if (t4) {
						g_p = find_math_student_by_stunum(head_math);
						if (g_p != NULL) {
							student_temp = g_p;
						}
					}
					printf("\033[5;0H��ӭ����%s", student_temp->student.name);
					SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED);
					printf("\033[7;0H���°���ִ�в���");
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
					flag = false;
				}
			}
			/*���ع��*/
			{
				HANDLE hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
				CONSOLE_CURSOR_INFO cursorInfo;
				GetConsoleCursorInfo(hStdout, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
				cursorInfo.bVisible = FALSE;					// ���ù��ɼ���ΪFALSE�����ع��  
				SetConsoleCursorInfo(hStdout, &cursorInfo);		// Ӧ���µĹ����Ϣ
			}
			TimeDisplay = true;
		}

		///*���̼��*/
		//char ch;
		//{
		//	for (;;)
		//	{
		//		if (key_is_pressed())
		//		{
		//			if ((GetAsyncKeyState(VK_CONTROL) & 0x8000))
		//			{
		//				if ((GetAsyncKeyState(81) & 0x8000))
		//				{
		//					if (MessageBox(hwnd, _T("��ȷ��Ҫ�˳���"), _T("��ʾ"), MB_YESNO) == IDYES)
		//					{
		//						system("cls");
		//						plink_list_head->access %= 10;
		//						exit(0);
		//					}
		//					else
		//					{
		//						ch = '\0';
		//						break;
		//					}
		//				}
		//			}
		//			else
		//			{
		//				ch = _getch();
		//				break;
		//			}
		//		}
		//	}
		//}
		char temp[3] = { 0 };
		temp[0] = *(plink_list_head->account);
		temp[1] = *((plink_list_head->account) + 1);
		
		
		memset(stunumglobal, 0, sizeof(stunumglobal));
		strcpy(stunumglobal, plink_list_head->account);
		calculate_gpa(student_temp);
		calculate_scores(plink_list_head);


		TimeDisplay = false;
		int t = 0;
		int userchoose = 0;
		system("cls");
		while (1) {
			if (userchoose == 0)setPrintColor(0x6f);
			gotoXY(1, 1);
			printf("1����ѯ���˻�����Ϣ\n");
			if (userchoose == 0)setPrintColor(0x0f);
			if (userchoose == 1)setPrintColor(0x6f);
			gotoXY(1, 3);
			printf("2���鿴ȫ���γ���ϸ��Ϣ\n");
			if (userchoose == 1)setPrintColor(0x0f);
			if (userchoose == 2)setPrintColor(0x6f);
			gotoXY(1, 5);
			printf("3���鿴ȫ���γ̳ɼ�\n");
			if (userchoose == 2)setPrintColor(0x0f);
			if (userchoose == 3)setPrintColor(0x6f);
			gotoXY(1, 7);
			printf("4���鿴��ǰƽ������\n");
			if (userchoose == 3)setPrintColor(0x0f);
			if (userchoose == 4)setPrintColor(0x6f);
			gotoXY(1, 9);
			printf("5���鿴���������Ϣ\n");
			if (userchoose == 4)setPrintColor(0x0f);

			char input = _getch();
			switch (input) {
			case 'W':
			case'w':userchoose -= 1;
				if (userchoose == -1) userchoose = 4;
				break;
			case 'S':
			case's':userchoose = (userchoose + 1) % 5;
				break;
			case 27:return;
				break;
			case'\r':
				switch (userchoose) {
				case 0:t = 1;
					print_a_student(student_temp);
					flag = true;
					break;
				case 1:t = 1;
					print_a_student_score(student_temp);
					flag = true;
					break;

				case 2:t = 1;
					system("cls");
					print_all_score(student_temp);
					system("pause");
					system("cls");
					flag = true;
					break;
				case 3:
					t = 1;
					student_calculate_gpa(student_temp);
					TimeDisplay = false;
					system("cls");
					printf("��ǰƽ������Ϊ��%lf\n", student_temp->student.GPA);
					student_calculate_gpa(student_temp);
					student_calculate_ranking(head_software, student_temp);
					system("pause");
					system("cls");
					flag = true;
					break;
				case 4:
					t = 1;
					TimeDisplay = false;

					recommend_exempt_menu();
					system("cls");
					flag = true;
					break;
				}
				if (t == 1)break;
				if (input == 27)return;
			}
		}
		return;
	}
}

void adm_teacher_menu(struct Node_Teacher* head_tea)
{
	for (;;)
	{
		/*UI*/
		{
			TimeDisplay = false;
			system("cls");
			SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
			printf("\033[1;1H[ESC] ����  [CTRL+Q] �˳�");
			SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
			draw_division_line();
			SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
			printf("\033[3;1H��ǰλ�ã���ʦ���������˵�");
			SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED);
			printf("\033[5;0H���°���ִ�в���\n");
			SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
			printf("\033[7;0H[1]�鿴��ʦ��Ϣ\n[2]���ӽ�ʦ��Ϣ\n[3]�޸Ľ�ʦ��Ϣ\n[4]ɾ����ʦ��Ϣ");
			/*���ع��*/
			{
				hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
				CONSOLE_CURSOR_INFO cursorInfo;
				GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
				cursorInfo.bVisible = FALSE;						// ���ù��ɼ���ΪFALSE�����ع��  
				SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
			}
			TimeDisplay = true;
		}

		/*���̼��*/
		char ch;
		{
			for (;;)
			{
				if (key_is_pressed())
				{
					if ((GetAsyncKeyState(VK_CONTROL) & 0x8000))
					{
						if ((GetAsyncKeyState(81) & 0x8000))
						{
							if (MessageBox(hwnd, _T("��ȷ��Ҫ�˳���"), _T("��ʾ"), MB_YESNO) == IDYES)
							{
								system("cls");
								plink_list_head->access %= 10;
								exit(0);
							}
							else
							{
								ch = '\0';
								break;
							}
						}
					}
					else
					{
						ch = _getch();
						break;
					}
				}
			}
		}

		if (ch == 27)
		{
			break;
		}
		else if (ch == '1')
		{
			print_teacher_information(head_tea);
		}
		else if (ch == '2')
		{
			add_teacher_information(head_tea);
		}
		else if (ch == '3')
		{
			modify_teacher_information(head_tea);
		}
		else if (ch == '4')
		{
			delete_teacher_information(head_tea);
		}
	}

	return;
}


void teacher_menu(struct Node_Teacher* head_tea)
{
	for (;;)
	{
		fread_teacher_out_file(head_tea);
		int test = 0;
		struct Node_Teacher* p = head_tea;
		char account[20] = { 0 };
		strcpy(account, plink_list_head->account);
		p = p->next;
		while (p != NULL)
		{
			int result = strcmp(p->teacher.teacher_ID, account);
			if (result == 0)
			{
				break;
			}
			p = p->next;
		}

		/*UI���*/
		{
			/*UI����*/
			{
				TimeDisplay = false;
				system("cls");
				SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
				printf("[ESC] ����");
				SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
				draw_division_line();
				SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
				printf("\033[3;1H��ǰλ�ã��û��˵�");
				SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
				printf("\033[8;0H[1] ��ѯ���˻�����Ϣ\n[2] ��ѯ��ѧ��ɼ���Ϣ\n");
				printf("\033[5;0H��ӭ����%s��", p->teacher.teacher_name);
				SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED);
				printf("\033[7;0H���°���ִ�в���");
				SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
			}
			/*���ع��*/
			{
				HANDLE hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
				CONSOLE_CURSOR_INFO cursorInfo;
				GetConsoleCursorInfo(hStdout, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
				cursorInfo.bVisible = FALSE;					// ���ù��ɼ���ΪFALSE�����ع��  
				SetConsoleCursorInfo(hStdout, &cursorInfo);		// Ӧ���µĹ����Ϣ
			}
			TimeDisplay = true;

		}
		char ch = _getch();
		if (ch == 27)		//����
			return;
		else if (ch == '1')
		{
			system("cls");
			int test = 0;
			struct Node_Teacher* p = head_tea;
			char account[20] = { 0 };
			strcpy(account, plink_list_head->account);
			p = p->next;
			while (p != NULL) {
				int result = strcmp(p->teacher.teacher_ID, account);
				if (result == 0) {
					printf("������Ϣ���£�\n");
					printf("������%s\n", p->teacher.teacher_name);
					printf("���ţ�%s\n", p->teacher.teacher_ID);
					printf("�Ա�%s\n", p->teacher.gender);
					printf("����ѧԺ��%s\n", p->teacher.college_belonging);
					printf("�����Ŀ��%s\n", p->teacher.subject);
					printf("����༶��\n");
					do {
						p = p->next2;
						printf("%s", p->teacher.class_collegeof);
						for (int i = 0; i < 5; i++) {
							if (p->teacher.class_num[i] != 0)
								printf("%d ", p->teacher.class_num[i]);
						}
						printf("��\n");
					} while (p->next2 != NULL);
					test = 1;
					break;
				}
				p = p->next;
			}
			system("pause");
		}
		else if (ch == '2')
		{
			printf("\n");
			view_scores_report();
		}

		
	}
}

void config_menu(void)
{
	bool flag = true;
	for (;;)
	{
		/*UI���*/
		if (flag)
		{
			/*UI����*/
			{
				TimeDisplay = false;
				system("cls");
				SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
				printf("[ESC] ����  [CTRL+Q] �˳�");
				SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
				draw_division_line();
				SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
				printf("\033[3;1H��ǰλ�ã��߼����ܲ˵�");
				SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
				printf("\033[6;0H[1]����������ӷ���Ŀ\n[2]���������ӷ���Ŀ����\n[3]�鿴��־\n[4]ͼ�λ�������Ϣ ");
				SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED);
				printf("\033[5;0H���°���ִ�в���");
				SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
				TimeDisplay = true;
			}
			/*���ع��*/
			{
				HANDLE hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
				CONSOLE_CURSOR_INFO cursorInfo;
				GetConsoleCursorInfo(hStdout, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
				cursorInfo.bVisible = FALSE;					// ���ù��ɼ���ΪFALSE�����ع��  
				SetConsoleCursorInfo(hStdout, &cursorInfo);		// Ӧ���µĹ����Ϣ
			}
			flag = false;
		}

		/*���̼��*/
		char ch;
		{
			for (;;)
			{
				if (key_is_pressed())
				{
					if ((GetAsyncKeyState(VK_CONTROL) & 0x8000))
					{
						if ((GetAsyncKeyState(81) & 0x8000))				//Q
						{
							if (MessageBox(hwnd, _T("��ȷ��Ҫ�˳���"), _T("��ʾ"), MB_YESNO) == IDYES)
							{
								system("cls");
								plink_list_head->access %= 10;
								exit(0);
							}
							else
							{
								ch = '\0';
								break;
							}
						}
					}
					else
					{
						ch = _getch();
						break;
					}
				}
			}
		}

		if (ch == 27)		//����
			return;
		else if (ch == '1')
		{
			view_extra_point_policy();
			flag = true;
			continue;
		}
		else if (ch == '2')
		{
			approve_extra_point_proof_selecting_part();
			flag = true;
			continue;
		}
		else if (ch == '3')
		{
			int result = system("start \"\" \".\\log\"");
			if (result == -1) {
				printf("Error opening the folder using system command.\n");
				system("pause");
				continue;
			}
		}
		else if (ch == '4')
		{
			struct Node_Teacher* head_tea = (struct Node_Teacher*)malloc(sizeof(struct Node_Teacher));
			head_tea->next = NULL;
			struct Node_Administrator* head_adm = (struct Node_Administrator*)malloc(sizeof(struct Node_Administrator));
			head_adm->next = NULL;
			create_initgraph_tea(head_adm, head_tea);
		}
	}
	return;
}

void initial_student(struct user* user_ptr)
{
	char temp[3] = { 0 };
	temp[0] = *(user_ptr->account);
	temp[1] = *((user_ptr->account) + 1);
	if (!strcmp(temp, "55"))
	{
		strcpy(stunumglobal, user_ptr->account);
	
		int t1 = load_software_student(head_software);
		if (t1) {
			if (find_software_student_by_stunum(head_software) != NULL) {
				student_temp = find_software_student_by_stunum(head_software);
			}
		}
	}
}


#endif
