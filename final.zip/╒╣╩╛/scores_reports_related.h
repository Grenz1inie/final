#ifndef SCORES_REPORT_RELATED_H
#define SCORES_REPORT_RELATED_H
///////////////////////////////////
#include"system_menu.h"
#include"header_and_tool.h"

void show_interface();
void input_student(struct Node_Student* head, char* g_a);
void print_all_student(struct Node_Student* head_software, struct Node_Student* head_physics, struct Node_Student* head_computer, struct Node_Student* head_math);
void student_intotal(struct Node_Student* head_software, struct Node_Student* head_physics, struct Node_Student* head_computer, struct Node_Student* head_math);
struct Node_Student* find_software_student_by_stunum(struct Node_Student* head_software);
struct Node_Student* find_math_student_by_stunum(struct Node_Student* head_math);
struct Node_Student* find_computer_student_by_stunum(struct Node_Student* head_computer);
struct Node_Student* find_physics_student_by_stunum(struct Node_Student* head_physics);
int load_software_student(struct Node_Student* head);
int load_physics_student(struct Node_Student* head);
int load_math_student(struct Node_Student* head);
int load_computer_student(struct Node_Student* head);
void print_a_student(struct Node_Student*);
void print_a_student_score(struct Node_Student* head);
void input_class(struct Node_Student* temp);
double getgpa(double score);
int judgepass(double);
char* judgenum();
void judgegrade(struct Node_Student* head);
void delete_student(struct Node_Student* head_software, struct Node_Student* head_physics, struct Node_Student* head_computer, struct Node_Student* head_math);
int teacher_delete_a_student(struct Node_Student* head);
void save_software_student(struct Node_Student* head);
void save_math_student(struct Node_Student* head);
void save_physics_student(struct Node_Student* head);
void save_computer_student(struct Node_Student* head);
void get_classnum(struct Node_Student* head);
void view_scores_report(void);
void setPrintColor(int color);
void gotoXY(int x, int y);
void clear(int x, int y, int w, int h);
void calculate_gpa(struct Node_Student* temp);
void change_student_information(struct Node_Student* temp);
void change_student_score(struct Node_Student* temp);
void student_calculate_gpa(struct Node_Student* temp);
void student_calculate_ranking(struct Node_Student* head, struct Node_Student* temp);
void teacher_print_all_student_score(struct Node_Student* head_software, struct Node_Student* head_physics, struct Node_Student* head_computer, struct Node_Student* head_math);
void print_all_score(struct Node_Student* temp);
void teacher_print_own_student_score(struct Node_Student* head_software, struct Node_Student* head_physics, struct Node_Student* head_computer, struct Node_Student* head_math);
void adm_view_scores_report(void);
void print_a_class_score(struct Node_Student* head_software, struct Node_Student* head_physics, struct Node_Student* head_computer, struct Node_Student* head_math);

char stunumglobal[10];
char stunumglobal_teacher[10];

char g_name[100];

//�γ�����
//����ѧ����Ϣ
struct Student {
	char collegeof[20];//ѧԺ����
	char teachername[20];//����Ա����
	char stunum[10];//ѧ��
	char name[50];//����
	char gender[5];//�Ա�
	int classnum;//�༶
	char tel[15];//�绰����
	char grade[10];//�꼶
	//////////////////////////
	char classtime[50];//�γ�ѧ��
	char classname[50];//�γ�����
	char classnum1[20];//�γ̺�
	char classnum2[20];//�����
	char classkind[20];//�γ����
	char classnature[10];//�γ�����
	double credit;//�γ�ѧ��
	int classhour;//ѧʱ
	char way[10];//�޶���ʽ
	char major_or_not[5];//�Ƿ�����
	char examtime[20];//����ʱ��
	double score;//�÷�

	double spare_score;//���޸ĵ÷�

	double GPA;//����
	char examkind[20];//��������
	char who_start[30];//���ε�λ
	char pass_or_not[5];//�Ƿ񼰸�
	char effective_or_not[5];//�Ƿ���Ч
	char selectclasskind[20];//У��ѡ���
	char reason[100];//����ԭ��
	int is_extra_point;//�Ƿ����뱣�гɼ�
};



//ѧ���������
struct Node_Student {
	struct Student student;
	struct Node_Student* nextx;
	struct Node_Student* nexty;
};

void view_scores_report(void)
{
	system("cls");
	TimeDisplay = false;


	int t1 = load_software_student(head_software);
	int t2 = load_physics_student(head_physics);
	int t3 = load_computer_student(head_computer);
	int t4 = load_math_student(head_math);
	int find = 0;

	//struct Node_Student* temp = (Node_Student*)malloc(sizeof(Node_Student));
	struct Node_Student* p1 = (Node_Student*)malloc(sizeof(Node_Student));
	int userchoose = 0;
	int userchoose0 = 0;
	int t = 0;
	int t0 = 0;
	char c[10];

	while (1) {

		/*UI���*/
		{
			SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
			printf("\033[1;1H[ESC] ����  [CTRL+Q] �˳�");
			draw_division_line();
			SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
			printf("\033[3;1H��ǰλ�ã�ѧ���ɼ������˵�");
			SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
			SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED);
			printf("\033[5;0H���°���ִ�в���");
			SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
			/*���ع��*/
			{
				hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
				CONSOLE_CURSOR_INFO cursorInfo;
				GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
				cursorInfo.bVisible = FALSE;						// ���ù��ɼ���ΪFALSE�����ع��  
				SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
			}
			//TimeDisplay = true;

		}


		if (userchoose0 == 0)setPrintColor(0x6f);
		gotoXY(1, 5);
		printf("1��¼��ѧ����Ϣ\n");
		if (userchoose0 == 0)setPrintColor(0x0f);
		if (userchoose0 == 1)setPrintColor(0x6f);
		gotoXY(1, 7);
		printf("2���鿴����ѧ����Ϣ\n");
		if (userchoose0 == 1)setPrintColor(0x0f);
		if (userchoose0 == 2)setPrintColor(0x6f);
		gotoXY(1, 9);
		printf("3���鿴ѧ��������\n");
		if (userchoose0 == 2)setPrintColor(0x0f);
		if (userchoose0 == 3)setPrintColor(0x6f);
		gotoXY(1, 11);
		printf("4��¼��γ�\n");
		if (userchoose0 == 3)setPrintColor(0x0f);
		if (userchoose0 == 4)setPrintColor(0x6f);
		gotoXY(1, 13);
		printf("5���鿴����ѧ���ɼ���\n");
		if (userchoose0 == 4)setPrintColor(0x0f);
		if (userchoose0 == 5)setPrintColor(0x6f);
		gotoXY(1, 15);
		printf("6���鿴ȫ��ѧ��\n");
		if (userchoose0 == 5)setPrintColor(0x0f);
		if (userchoose0 == 6)setPrintColor(0x6f);
		gotoXY(1, 17);
		printf("7���鿴��ѧ��ȫ��ѧ���ı���Ŀ�ɼ�\n");
		if (userchoose0 == 6)setPrintColor(0x0f);
		if (userchoose0 == 7)setPrintColor(0x6f);
		gotoXY(1, 19);
		printf("8���鿴����Ŀȫ��ѧ���ɼ�");
		if (userchoose0 == 7)setPrintColor(0x0f);
		if (userchoose0 == 8)setPrintColor(0x6f);
		gotoXY(1, 21);
		printf("9��ɾ��ѧ��");
		if (userchoose0 == 8)setPrintColor(0x0f);
		if (userchoose0 == 9)setPrintColor(0x6f);
		gotoXY(1, 23);
		printf("10���޸�ѧ����Ϣ");
		if (userchoose0 == 9)setPrintColor(0x0f);
		if (userchoose0 == 10)setPrintColor(0x6f);
		gotoXY(1, 25);
		printf("11���޸�ѧ���ɼ�");
		if (userchoose0 == 10)setPrintColor(0x0f);

		char input0 = _getch();
		switch (input0) {
		case 72:
		case 'W':
		case'w':userchoose0 -= 1;
			if (userchoose0 == -1) userchoose0 = 10;
			break;
		case 80:
		case 'S':
		case's':userchoose0 = (userchoose0 + 1) % 11;
			break;
		case 27:t0 = 1;
			break;
		case'\r':
			switch (userchoose0) {
			case 0:
				t0 = 1;
				system("cls");
				char g_a[100];
				printf("��ѡ��ѧ����ѧԺ");
				while (1) {
					if (userchoose == 0) setPrintColor(0x6f);
					gotoXY(1, 3);
					printf("����ѧԺ");
					if (userchoose == 0) setPrintColor(0x0f);
					if (userchoose == 1) setPrintColor(0x6f);
					gotoXY(1, 5);
					printf("�����ѧԺ");
					if (userchoose == 1) setPrintColor(0x0f);
					if (userchoose == 2) setPrintColor(0x6f);
					gotoXY(1, 7);
					printf("����ѧԺ");
					if (userchoose == 2) setPrintColor(0x0f);
					if (userchoose == 3) setPrintColor(0x6f);
					gotoXY(1, 9);
					printf("��ѧѧԺ");
					if (userchoose == 3) setPrintColor(0x0f);

					char input = _getch();
					switch (input) {
					case 72:
					case 'W':
					case'w':userchoose -= 1;
						if (userchoose == -1) userchoose = 3;
						break;
					case 80:
					case 'S':
					case's':userchoose = (userchoose + 1) % 4;
						break;
					case'\r':
						switch (userchoose) {
						case 0: t = 1;
							strcpy(g_a, "����ѧԺ");
							gotoXY(1, 13);
							input_student(head_software, g_a);
							break;
						case 1:t = 1;
							strcpy(g_a, "�����ѧԺ");
							gotoXY(1, 13);
							input_student(head_computer, g_a);
							break;
						case 2:t = 1;
							strcpy(g_a, "����ѧԺ");
							gotoXY(1, 13);
							input_student(head_physics, g_a);
							break;
						case 3:t = 1;
							strcpy(g_a, "��ѧѧԺ");
							gotoXY(1, 13);
							input_student(head_math, g_a);
							break;
						}
						break;
					case 27:
						t = 1;	
						break;
					}
					if (t == 1) break;
				}
				system("cls");
				break;
			case 1:
				system("cls");
				t0 = 1;
				printf("������Ҫ���ҵ�ѧ��");
				student_temp == NULL;
				strcpy(stunumglobal, judgenum());
				if (t1) {
					p1 = find_software_student_by_stunum(head_software);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t2) {
					p1 = find_physics_student_by_stunum(head_physics);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t3) {
					p1 = find_computer_student_by_stunum(head_computer);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t4) {
					p1 = find_math_student_by_stunum(head_math);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (student_temp == NULL) {
					printf("û�и�ѧ��");
					system("pause");
					system("cls");
					return;

				}
				if (strcmp(student_temp->student.name, "0") != 0) {
					print_a_student(student_temp);
				}
				else {
					t0 = 0;
					printf("û�и�ѧ��");
					system("pause");
					system("cls");
					break;
				}
				break;

			case 2:
				t0 = 1;
				printf("\n");
				printf("\n");
				student_intotal(head_software, head_physics, head_computer, head_math);
				system("cls");
				break;
			case 3:
				t0 = 1;
				system("cls");
				printf("�������ѧ��ѧ��");
				strcpy(stunumglobal, judgenum());
				student_temp = NULL;
				if (t1) {
					p1 = find_software_student_by_stunum(head_software);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t2) {
					p1 = find_physics_student_by_stunum(head_physics);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t3) {
					p1 = find_computer_student_by_stunum(head_computer);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t4) {
					p1 = find_math_student_by_stunum(head_math);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (student_temp == NULL) {
					printf("û�и�ѧ��");
					system("pause");
					system("cls");
					return;
				}
				if (strcmp(student_temp->student.name, "0") != 0) {
					print_a_student(student_temp);
				}
				else {
					t0 = 0;
					printf("û�и�ѧ��");
					system("pause");
					system("cls");
					break;
				}
				input_class(student_temp);
				break;
			case 4:
				t0 = 1;
				system("cls");
				student_temp = NULL;
				printf("������Ҫ���ҵ�ѧ����ѧ��");
				strcpy(stunumglobal, judgenum());
				if (t1) {
					p1 = find_software_student_by_stunum(head_software);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t2) {
					p1 = find_physics_student_by_stunum(head_physics);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t3) {
					p1 = find_computer_student_by_stunum(head_computer);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t4) {
					p1 = find_math_student_by_stunum(head_math);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (student_temp == NULL) {
					printf("û�и�ѧ��");
					system("pause");
					system("cls");
					return;

				}
				if (strcmp(student_temp->student.name, "0") != 0) {
					print_a_student(student_temp);
				}
				else {
					t0 = 0;
					printf("û�и�ѧ��");
					system("pause");
					system("cls");
					break;
				}
				print_a_student_score(student_temp);
				break;
			case 5:
				//t0 = 1;
				system("cls");
				print_all_student(head_software, head_physics, head_computer, head_math);
				break;
			case 6:t0 = 1;
				system("cls");
				teacher_print_own_student_score(head_software, head_physics, head_computer, head_math);


				system("pause");
				system("cls");
				break;
			case 7:
				t0 = 1;
				system("cls");
				teacher_print_all_student_score(head_software, head_physics, head_computer, head_math);
				system("pause");
				system("cls");
				break;
			case 8:
				t0 = 1;
				printf("\n");
				//strcpy(stunumglobal, judgenum());
				/*if (t1) {
					p1 = find_software_student_by_stunum(head_software);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t2) {
					p1 = find_physics_student_by_stunum(head_physics);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t3) {
					p1 = find_computer_student_by_stunum(head_computer);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t4) {
					p1 = find_math_student_by_stunum(head_math);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (strcmp(student_temp->student.name, "0") != 0) {
					print_a_student(student_temp);
				}
				else {
					t0 = 0;
					printf("û�и�ѧ��");
					system("pause");
					system("cls");
					break;
				}*/
				delete_student(head_software, head_physics, head_computer, head_math);
				break;
			case 9:
				t0 = 1;
				system("cls");
				student_temp = NULL;
				printf("������Ҫ�޸ĵ�ѧ��ѧ��");
				strcpy(stunumglobal, judgenum());
				if (t1) {
					p1 = find_software_student_by_stunum(head_software);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t2) {
					p1 = find_physics_student_by_stunum(head_physics);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t3) {
					p1 = find_computer_student_by_stunum(head_computer);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t4) {
					p1 = find_math_student_by_stunum(head_math);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (student_temp == NULL) {
					printf("û�и�ѧ��");
					system("pause");
					system("cls");
					return;

				}
				if (strcmp(student_temp->student.name, "0") != 0) {
					print_a_student(student_temp);
				}
				else {
					t0 = 0;
					printf("û�и�ѧ��");
					system("pause");
					system("cls");
					break;
				}
				change_student_information(student_temp);
				system("cls");
				break;
			case 10:
				t0 = 1;
				printf("\n");
				printf("\n");
				student_temp = NULL;
				printf("������Ҫ�޸ĵ�ѧ��");
				strcpy(stunumglobal, judgenum());

				if (t1) {
					p1 = find_software_student_by_stunum(head_software);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t2) {
					p1 = find_physics_student_by_stunum(head_physics);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t3) {
					p1 = find_computer_student_by_stunum(head_computer);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t4) {
					p1 = find_math_student_by_stunum(head_math);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (student_temp == NULL) {
					printf("û�и�ѧ��");
					system("pause");
					system("cls");
					return;

				}
				if (strcmp(student_temp->student.name, "0") != 0) {
					print_a_student(student_temp);
				}
				else {
					t0 = 0;
					printf("û�и�ѧ��");
					system("pause");
					system("cls");
					break;
				}
				change_student_score(student_temp);
				system("cls");
				break;

			}
		}
		save_computer_student(head_computer);
		save_software_student(head_software);
		save_math_student(head_math);
		save_physics_student(head_physics);

		if (input0 == 27)break;
	}
	return;
}
void adm_view_scores_report(void)
{
	system("cls");
	TimeDisplay = false;


	int t1 = load_software_student(head_software);
	int t2 = load_physics_student(head_physics);
	int t3 = load_computer_student(head_computer);
	int t4 = load_math_student(head_math);
	int find = 0;

	//struct Node_Student* temp = (Node_Student*)malloc(sizeof(Node_Student));
	struct Node_Student* p1 = (Node_Student*)malloc(sizeof(Node_Student));
	int userchoose = 0;
	int userchoose0 = 0;
	int t = 0;
	int t0 = 0;
	char c[10];

	while (1) {

		/*UI���*/
		{

			SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
			printf("\033[1;1H[ESC] ����  [CTRL+Q] �˳�");
			draw_division_line();
			SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
			printf("\033[3;1H��ǰλ�ã�ѧ���ɼ������˵�");
			SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
			SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED);
			printf("\033[5;0H���°���ִ�в���");
			SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
			/*���ع��*/
			{
				hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
				CONSOLE_CURSOR_INFO cursorInfo;
				GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
				cursorInfo.bVisible = FALSE;						// ���ù��ɼ���ΪFALSE�����ع��  
				SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
			}
			//TimeDisplay = true;

		}


		if (userchoose0 == 0)setPrintColor(0x6f);
		gotoXY(1, 5);
		printf("1��¼��ѧ����Ϣ");
		if (userchoose0 == 0)setPrintColor(0x0f);
		if (userchoose0 == 1)setPrintColor(0x6f);
		gotoXY(1, 7);
		printf("2���鿴����ѧ����Ϣ");
		if (userchoose0 == 1)setPrintColor(0x0f);
		if (userchoose0 == 2)setPrintColor(0x6f);
		gotoXY(1, 9);
		printf("3���鿴ѧ��������");
		if (userchoose0 == 2)setPrintColor(0x0f);
		if (userchoose0 == 3)setPrintColor(0x6f);
		gotoXY(1, 11);
		printf("4��¼��γ�");
		if (userchoose0 == 3)setPrintColor(0x0f);
		if (userchoose0 == 4)setPrintColor(0x6f);
		gotoXY(1, 13);
		printf("5���鿴����ѧ���ɼ���");
		if (userchoose0 == 4)setPrintColor(0x0f);
		if (userchoose0 == 5)setPrintColor(0x6f);
		gotoXY(1, 15);
		printf("6���鿴ȫ��ѧ��");
		if (userchoose0 == 5)setPrintColor(0x0f);
		if (userchoose0 == 6)setPrintColor(0x6f);
		gotoXY(1, 17);
		printf("7��ɾ��ѧ��");
		if (userchoose0 == 6)setPrintColor(0x0f);
		if (userchoose0 == 7)setPrintColor(0x6f);
		gotoXY(1, 19);
		printf("8���޸�ѧ����Ϣ");
		if (userchoose0 == 7)setPrintColor(0x0f);
		if (userchoose0 == 8)setPrintColor(0x6f);
		gotoXY(1, 21);
		printf("9���޸�ѧ���ɼ�");
		if (userchoose0 == 8)setPrintColor(0x0f);


		t = 0;
		char input0 = _getch();
		switch (input0) {
		case 72:
		case 'W':
		case'w':userchoose0 -= 1;
			if (userchoose0 == -1) userchoose0 = 8;
			break;
		case 80:
		case 'S':
		case's':userchoose0 = (userchoose0 + 1) % 9;
			break;
		case 27:t0 = 1;
			break;
		case'\r':
			switch (userchoose0) {
			case 0:
				t0 = 1;
				system("cls");
				char g_a[100];
				printf("��ѡ��ѧ����ѧԺ");
				while (1) {
					if (userchoose == 0) setPrintColor(0x6f);
					gotoXY(1, 3);
					printf("����ѧԺ");
					if (userchoose == 0) setPrintColor(0x0f);
					if (userchoose == 1) setPrintColor(0x6f);
					gotoXY(1, 5);
					printf("�����ѧԺ");
					if (userchoose == 1) setPrintColor(0x0f);
					if (userchoose == 2) setPrintColor(0x6f);
					gotoXY(1, 7);
					printf("����ѧԺ");
					if (userchoose == 2) setPrintColor(0x0f);
					if (userchoose == 3) setPrintColor(0x6f);
					gotoXY(1, 9);
					printf("��ѧѧԺ");
					if (userchoose == 3) setPrintColor(0x0f);

					char input = _getch();
					switch (input) {
					case 72:
					case 'W':
					case'w':userchoose -= 1;
						if (userchoose == -1) userchoose = 3;
						break;
					case 80:
					case 'S':
					case's':userchoose = (userchoose + 1) % 4;
						break;
					case'\r':
						switch (userchoose) {
						case 0: t = 1;
							strcpy(g_a, "����ѧԺ");
							gotoXY(1, 13);
							input_student(head_software, g_a);
							break;
						case 1:t = 1;
							strcpy(g_a, "�����ѧԺ");
							gotoXY(1, 13);
							input_student(head_computer, g_a);
							break;
						case 2:t = 1;
							strcpy(g_a, "����ѧԺ");
							gotoXY(1, 13);
							input_student(head_physics, g_a);
							break;
						case 3:t = 1;
							strcpy(g_a, "��ѧѧԺ");
							gotoXY(1, 13);
							input_student(head_math, g_a);
							break;
						}
						break;
					case 27:
						t = 1;
						t0 = 0;
						break;
					}
					if (t == 1) break;
				}
				system("cls");
				break;
			case 1:
				system("cls");
				t0 = 1;
				student_temp = NULL;
				printf("������Ҫ���ҵ�ѧ��");
				strcpy(stunumglobal, judgenum());
				if (t1) {
					p1 = find_software_student_by_stunum(head_software);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t2) {
					p1 = find_physics_student_by_stunum(head_physics);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t3) {
					p1 = find_computer_student_by_stunum(head_computer);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t4) {
					p1 = find_math_student_by_stunum(head_math);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (student_temp == NULL) {
					printf("û�и�ѧ��");
					system("pause");
					system("cls");
					return;

				}
				if (strcmp(student_temp->student.name, "0") != 0) {
					print_a_student(student_temp);
				}
				else {
					t0 = 0;
					printf("û�и�ѧ��");
					system("pause");
					system("cls");
					break;
				}
				break;

			case 2:
				printf("\n");
				t0 = 1;
				student_intotal(head_software, head_physics, head_computer, head_math);
				break;
			case 3:
				t0 = 1;
				system("cls");
				student_temp = NULL;
				printf("�������ѧ��ѧ��");
				strcpy(stunumglobal, judgenum());
				
				if (t1) {
					p1 = find_software_student_by_stunum(head_software);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t2) {
					p1 = find_physics_student_by_stunum(head_physics);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t3) {
					p1 = find_computer_student_by_stunum(head_computer);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t4) {
					p1 = find_math_student_by_stunum(head_math);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (student_temp == NULL) {
					printf("û�и�ѧ��");
					system("pause");
					system("cls");
					return;

				}
				if (strcmp(student_temp->student.name, "0") != 0) {
					print_a_student(student_temp);
				}
				else {
					t0 = 0;
					printf("û�и�ѧ��");
					system("pause");
					system("cls");
					break;
				}
				input_class(student_temp);
				break;
			case 4:
				t0 = 1;
				system("cls");
				student_temp = NULL;
				printf("������Ҫ���ҵ�ѧ����ѧ��");
				strcpy(stunumglobal, judgenum());
				if (t1) {
					p1 = find_software_student_by_stunum(head_software);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t2) {
					p1 = find_physics_student_by_stunum(head_physics);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t3) {
					p1 = find_computer_student_by_stunum(head_computer);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t4) {
					p1 = find_math_student_by_stunum(head_math);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (student_temp == NULL) {
					printf("û�и�ѧ��");
					system("pause");
					system("cls");
					return;

				}
				if (student_temp != NULL) {
					print_a_student(student_temp);
				}
				else {
					t0 = 0;
					printf("û�и�ѧ��");
					system("pause");
					system("cls");
					break;
				}
				print_a_student_score(student_temp);
				break;
			case 5:
				system("cls");
				//t0 = 1;
				print_all_student(head_software, head_physics, head_computer, head_math);
				break;
			case 6:
				t0 = 1;
				printf("\n");
				/*
				if (t1) {
					p1 = find_software_student_by_stunum(head_software);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t2) {
					p1 = find_physics_student_by_stunum(head_physics);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t3) {
					p1 = find_computer_student_by_stunum(head_computer);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t4) {
					p1 = find_math_student_by_stunum(head_math);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (strcmp(student_temp->student.name, "0") != 0) {
					print_a_student(student_temp);
				}
				else {
					t0 = 0;
					printf("û�и�ѧ��");
					system("pause");
					system("cls");
					break;
				}*/
				delete_student(head_software, head_physics, head_computer, head_math);
				break;
			case 7:
				t0 = 1;
				system("cls");
				student_temp = NULL;
				printf("������Ҫ�޸ĵ�ѧ��ѧ��");
				strcpy(stunumglobal, judgenum());
				if (t1) {
					p1 = find_software_student_by_stunum(head_software);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t2) {
					p1 = find_physics_student_by_stunum(head_physics);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t3) {
					p1 = find_computer_student_by_stunum(head_computer);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t4) {
					p1 = find_math_student_by_stunum(head_math);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (student_temp == NULL) {
					printf("û�и�ѧ��");
					system("pause");
					system("cls");
					return;

				}
				if (strcmp(student_temp->student.name, "0") != 0) {
					print_a_student(student_temp);
				}
				else {
					t0 = 0;
					printf("û�и�ѧ��");
					system("pause");
					system("cls");
					break;
				}
				change_student_information(student_temp);
				system("cls");
				break;
			case 8:
				t0 = 1;
				printf("\n");
				printf("\n");
				student_temp = NULL;
				printf("������Ҫ�޸ĵ�ѧ��");
				strcpy(stunumglobal, judgenum());
				if (t1) {
					p1 = find_software_student_by_stunum(head_software);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t2) {
					p1 = find_physics_student_by_stunum(head_physics);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t3) {
					p1 = find_computer_student_by_stunum(head_computer);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (t4) {
					p1 = find_math_student_by_stunum(head_math);
					if (p1 != NULL) {
						if (strcmp(p1->student.name, "0") != 0) {
							student_temp = p1;
						}
					}
				}
				if (student_temp == NULL) {
					printf("û�и�ѧ��");
					system("pause");
					system("cls");
					return;

				}
				if (strcmp(student_temp->student.name, "0") != 0) {
					print_a_student(student_temp);
				}
				else {
					t0 = 0;
					printf("û�и�ѧ��");
					system("pause");
					system("cls");
					break;
				}
				change_student_score(student_temp);
				system("cls");
				break;
			}

		}
		save_computer_student(head_computer);
		save_software_student(head_software);
		save_physics_student(head_physics);
		//if (t0 == 1)break;
		if (input0 == 27)break;
	}
	return;
}


void show_interface() {
	printf("1��¼��ѧ����Ϣ\n");
	printf("2���鿴����ѧ����Ϣ\n");
	printf("3���鿴ѧ��������\n");
	printf("4��¼��γ�\n");
	printf("5���鿴����ѧ���ɼ���\n");
	printf("6���鿴ȫ��ѧ��\n");
	printf("7���鿴���꼶ȫ��ѧ���ı���Ŀ�ɼ��ɼ�\n");
	printf("8��ɾ��ѧ��\n");
	printf("9���޸�ѧ����Ϣ\n");
	printf("10���޸�ѧ���ɼ�\n");
	printf("0���˳��ý���\n");

}
//����ѧ��������Ϣ
void input_student(struct Node_Student* head, char* g_a) {
	/*��ʾ���*/
	{
		hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
		CONSOLE_CURSOR_INFO cursorInfo;
		GetConsoleCursorInfo(hConsole, &cursorInfo);		// ��ȡ��ǰ�����Ϣ  
		cursorInfo.bVisible = TRUE;						// ���ù��ɼ���ΪFALSE�����ع��  
		SetConsoleCursorInfo(hConsole, &cursorInfo);		// Ӧ���µĹ����Ϣ
	}
	Node_Student* fresh = (Node_Student*)malloc(sizeof(Node_Student));
	fresh->nextx = NULL;
	fresh->nexty = NULL;
	//������ѧ��
	struct Node_Student* temp = head;
	struct Node_Student* p = head;
	printf("�������ѧ��ѧ��\n");
	char* tempchar = judgenum();
	while (p->nextx != NULL) {
		p = p->nextx;
		while (strcmp(p->student.stunum, tempchar) == 0) {
			printf("�Ѿ��и�ѧ��");
			system("pause");
			return;
		}
	}
	strcpy(fresh->student.stunum, tempchar);
	while (temp->nextx != NULL) {
		temp = temp->nextx;
	}
	temp->nextx = fresh;
	strcpy(fresh->student.classname, "0");
	strcpy(fresh->student.classtime, "0");
	strcpy(fresh->student.classnum1, "0");
	strcpy(fresh->student.classnum2, "0");
	strcpy(fresh->student.classkind, "0");
	strcpy(fresh->student.classnature, "0");
	strcpy(fresh->student.way, "0");
	strcpy(fresh->student.major_or_not, "0");
	strcpy(fresh->student.examtime, "0");
	strcpy(fresh->student.examkind, "0");
	strcpy(fresh->student.who_start, "0");
	strcpy(fresh->student.pass_or_not, "0");
	strcpy(fresh->student.effective_or_not, "0");
	strcpy(fresh->student.selectclasskind, "0");
	strcpy(fresh->student.reason, "0");
	fresh->student.credit = 0;
	fresh->student.classhour = 0;
	fresh->student.GPA = 0;
	fresh->student.score = 0;
	fresh->student.spare_score = 0;
	strcpy(fresh->student.tel, "0");
	strcpy(fresh->student.grade, "0");
	fresh->student.is_extra_point = 0;

	//Student
	printf("�������ѧ������\n");
	scanf("%s", fresh->student.name);
	strcpy(fresh->student.collegeof, g_a);
	printf("������ѧ���ĸ���Ա��ʦ����\n");
	scanf("%s", fresh->student.teachername);
	printf("�������ѧ���Ա�\n");
	scanf("%s", fresh->student.gender);
	get_classnum(fresh);
	judgegrade(fresh);


	if (plink_list_head->access % 10 == 2)
	{
		log_file = fopen(LogName, "a");
		fprintf(log_file, "%s  ", LogTime);
		fwprintf(log_file, L"%ls", plink_list_head->name);
		fprintf(log_file, "����ѧ����%s  \n\n", fresh->student.name);
	}
	else if (plink_list_head->access % 10 == 1 && teacher_global)
	{
		log_file = fopen(LogName, "a");
		fprintf(log_file, "%s  ", LogTime);
		fprintf(log_file, "%s ����ѧ����%s\n\n", teacher_global->teacher.teacher_name, fresh->student.name);
	}
	fclose(log_file);

	FILE* pf = fopen("user.txt", "ab+");
	struct user student;
	struct user* student_ptr = &student;
	initial_user_info(student_ptr);
	strcpy(student_ptr->account, fresh->student.stunum);
	strcpy(student_ptr->password, fresh->student.stunum);
	strcpy(student_ptr->phone_number, fresh->student.stunum);
	fwrite(student_ptr, sizeof(struct user), 1, pf);
	fclose(pf);


	printf("�������\n");
	system("pause");
}


//���ӵ���ѧ���γ�
void input_class(struct Node_Student* temp) {
	struct Node_Student* fresh = (Node_Student*)malloc(sizeof(Node_Student));
	fresh->nextx = NULL;
	fresh->nexty = NULL;
	//�����¿γ�
	struct Node_Student* p = temp;
	struct Node_Student* p1 = p;
	while (temp->nexty != NULL) {
		temp = temp->nexty;
	}

	temp->nexty = fresh;
	temp = temp->nexty;
	temp->student = p->student;
	printf("������ѧ��ѧ��");
	scanf("%s", temp->student.classtime);
	printf("������γ�����");
	scanf("%s", temp->student.classname);
	while (p1->nexty != NULL) {
		p1 = p1->nexty;
		if (p1 != temp) {
			if (strcmp(temp->student.classname, p1->student.classname) == 0) {
				printf("��¼��ÿγ�");
				return;
			}
		}
	}
	p1 = p;
	long number;
	printf("������γ̷���");
	for (;;)
	{
		char numberStr[100] = { 0 };
		if (scanf("%99s", numberStr) != 1)
		{
			printf("��������ȷ�ķ���");
			continue;
		}
		char* endptr;
		number = strtol(numberStr, &endptr, 10); // ���ַ���ת��Ϊ������  

		// ���ת���Ƿ�ɹ��������ַ���ֻ��������  
		if (*endptr != '\0' || !isdigit((unsigned char)*numberStr))
		{
			printf("��������ȷ�ķ���");
			continue;
		}

		// ��������Ƿ���0��100֮��  
		if (number < 0 || number > 100) {
			printf("��������ȷ�ķ���");
			continue;
		}
		else
			break;
	}
	temp->student.score = (int)number;
	printf("������γ̺�");
	scanf("%s", temp->student.classnum1);
	
	p1 = p;
	printf("����������");
	scanf("%s", temp->student.classnum2);
	
	p1 = p;
	printf("������γ����");
	scanf("%s", temp->student.classkind);
	//printf("������γ�����");
	printf("������γ�����");
	scanf("%s", temp->student.classnature);
	printf("������γ�ѧ��");
	scanf("%lf", &temp->student.credit);
	while (temp->student.credit < 0 || temp->student.credit>5) {
		printf("��������ȷ��ѧ��");
		scanf("%lf", &temp->student.credit);
	}
	printf("������γ�ѧʱ");
	scanf("%d", &temp->student.classhour);
	printf("������γ��޶���ʽ");
	scanf("%s", temp->student.way);
	printf("������γ��Ƿ�����,�����ǻ��");
	scanf("%s", temp->student.major_or_not);
	while ((strcmp(temp->student.major_or_not, "��")) != 0 && (strcmp(temp->student.major_or_not, "��")) != 0) {
		printf("��������ȷ�ĸ�ʽ");
		scanf("%s", temp->student.major_or_not);
	}
	printf("������γ̿�������");
	scanf("%s", temp->student.examtime);
	//����
	temp->student.GPA = getgpa(temp->student.score);
	printf("������γ̿�������");
	scanf("%s", temp->student.examkind);
	printf("������γ̿��ε�λ");
	scanf("%s", temp->student.who_start);
	//�Ƿ񼰸�
	if (judgepass(temp->student.score)) {
		strcpy(temp->student.pass_or_not, "��");
	}
	else {
		strcpy(temp->student.pass_or_not, "��");
	}
	printf("������γ��Ƿ���Ч");
	scanf("%s", temp->student.effective_or_not);
	while ((strcmp(temp->student.effective_or_not, "��")) != 0 && (strcmp(temp->student.effective_or_not, "��")) != 0) {
		printf("��������ȷ�ĸ�ʽ");
		scanf("%s", temp->student.effective_or_not);
	}
	printf("������γ��Ƿ�������ԭ��.����,������ԭ��,����,������0");
	char a[100];
	scanf("%s", a);
	if (strcmp(a, "0") == 0) {
		strcpy(temp->student.reason, "��");
	}
	else {
		strcpy(temp->student.reason, a);
	}
	student_calculate_gpa(p);

	log_file = fopen(LogName, "a");
	fprintf(log_file, "%s  ", LogTime);
	fprintf(log_file, "ѧ�� %s �γ̣�%s\n\n", temp->student.name, temp->student.classname);

	system("cls");
}

//ģ����ӡȫ��ѧ��
void print_all_student(struct Node_Student* head_software, struct Node_Student* head_physics, struct Node_Student* head_computer, struct Node_Student* head_math) {//������
	//load_computer_student();
	struct Node_Student* temp = head_software;
	while (temp->nextx != NULL) {
		//printf ("ѧ��:%s ����:%s �ɼ�:%d", temp->student.stunum, temp->student.name, temp->student.a.score);
		printf("%s:%s  ѧ�ţ�%s\n", temp->nextx->student.collegeof, temp->nextx->student.name, temp->nextx->student.stunum);
		temp = temp->nextx;
	}//
	temp = head_math;
	while (temp->nextx != NULL) {
		printf("%s:%s  ѧ�ţ�%s\n", temp->nextx->student.collegeof, temp->nextx->student.name, temp->nextx->student.stunum);
		temp = temp->nextx;
	}
	temp = head_physics;
	while (temp->nextx != NULL) {
		printf("%s:%s  ѧ�ţ�%s\n", temp->nextx->student.collegeof, temp->nextx->student.name, temp->nextx->student.stunum);
		temp = temp->nextx;
	}
	temp = head_computer;
	while (temp->nextx != NULL) {
		printf("%s:%s  ѧ�ţ�%s\n", temp->nextx->student.collegeof, temp->nextx->student.name, temp->nextx->student.stunum);
		temp = temp->nextx;
	}
	system("pause");
	system("cls");
}
//ͳ��ѧ��������
void student_intotal(struct Node_Student* head_software, struct Node_Student* head_physics, struct Node_Student* head_computer, struct Node_Student* head_math) {
	int total = 0;
	struct Node_Student* temp = (struct Node_Student*)malloc(sizeof(struct Node_Student));
	if (head_software->nextx != NULL) {
		temp = head_software->nextx;
		while (temp != NULL) {
			total++;
			temp = temp->nextx;
		}
	}
	if (head_physics->nextx != NULL) {
		temp = head_physics->nextx;
		while (temp != NULL) {
			total++;
			temp = temp->nextx;
		}
	}
	if (head_math->nextx != NULL) {
		temp = head_math->nextx;
		while (temp != NULL) {
			total++;
			temp = temp->nextx;
		}
	}
	if (head_computer->nextx != NULL) {
		temp = head_computer->nextx;
		while (temp != NULL) {
			total++;
			temp = temp->nextx;
		}
	}
	printf("��ѧУ����%d��ѧ��", total);
	system("pause");
	system("cls");
}
//ͨ��ѧ�Ų���ѧ��
struct Node_Student* find_software_student_by_stunum(struct Node_Student* head_software) {
	struct Node_Student* temp_software = head_software;
	while (temp_software->nextx != NULL) {
		temp_software = temp_software->nextx;
		if (strcmp(temp_software->student.stunum, stunumglobal) == 0) {
			return temp_software;
		}
	}
	return NULL;
}
struct Node_Student* find_math_student_by_stunum(struct Node_Student* head_math) {
	load_math_student(head_math);
	struct Node_Student* temp_math = head_math;
	while (temp_math->nextx != NULL) {
		temp_math = temp_math->nextx;
		if (strcmp(temp_math->student.stunum, stunumglobal) == 0) {
			return temp_math;
		}
	}
	return NULL;
}
struct Node_Student* find_computer_student_by_stunum(struct Node_Student* head_computer) {
	load_computer_student(head_computer);
	struct Node_Student* temp_computer = head_computer;

	while (temp_computer->nextx != NULL) {
		temp_computer = temp_computer->nextx;
		if (strcmp(temp_computer->student.stunum, stunumglobal) == 0) {
			return temp_computer;
		}
	}
	return NULL;
}
struct Node_Student* find_physics_student_by_stunum(struct Node_Student* head_physics) {
	load_physics_student(head_physics);
	struct Node_Student* temp_physics = head_physics;

	while (temp_physics->nextx != NULL) {
		temp_physics = temp_physics->nextx;
		if (strcmp(temp_physics->student.stunum, stunumglobal) == 0) {
			return temp_physics;
		}
	}
	return NULL;
}
//����ѧ�Ų�ѯ����ѧ��������Ϣ
void print_a_student(struct Node_Student* temp) {

	TimeDisplay = false;
	system("cls");
	printf("\033[1;1H");
	printf("����:%s\nѧԺ:%s\n����Ա:%s\n�Ա�:%s\n�꼶:%s\n", temp->student.name, temp->student.collegeof, temp->student.teachername, temp->student.gender, temp->student.grade);
	//��ȫ
	system("pause");
	system("cls");
}



//��ѯ����ѧ����ϸ�ɼ���Ϣ
void print_a_student_score(struct Node_Student* temp) {
	TimeDisplay = false;
	system("cls");
	printf("\033[1;1H");
	temp = temp->nexty;
	while (temp != NULL) {
		if ((strcmp(temp->student.stunum, stunumglobal)) == 0) {
			printf("�γ�����:%s\n", temp->student.classname);
			printf("�γ�ѧ��:%.1f\n", temp->student.credit);
			printf("�γ�ѧ��ѧ��:%s\n", temp->student.classtime);
			printf("�γ̷���:%.2lf\n", temp->student.score);
			printf("�γ̺�:%s\n", temp->student.classnum1);
			printf("�����:%s\n", temp->student.classnum2);
			printf("�γ����:%s\n", temp->student.classkind);
			printf("�γ�����:%s\n", temp->student.classnature);
			printf("�γ̼���:%.1f\n", temp->student.GPA);
			printf("�γ�ѧʱ:%d\n", temp->student.classhour);
			printf("�γ��޶���ʽ:%s\n", temp->student.way);
			printf("�γ��Ƿ�����:%s\n", temp->student.major_or_not);
			printf("�γ̿�������:%s\n", temp->student.examtime);
			printf("�γ̿�������:%s\n", temp->student.examkind);
			printf("�γ̿��ε�λ:%s\n", temp->student.who_start);
			printf("�ɼ��Ƿ񼰸�:%s\n", temp->student.pass_or_not);
			printf("�ɼ��Ƿ���Ч:%s\n", temp->student.effective_or_not);
			printf("�γ��Ƿ�������ԭ��:%s\n", temp->student.reason);
			system("pause");
			system("cls");
		}
		temp = temp->nexty;
	}

}

//д���ļ�
void save_software_student(struct Node_Student* head) {
	FILE* file = fopen("./student_software.txt", "w");
	struct Node_Student* tempx = head->nextx;
	struct Node_Student* tempy = head->nextx;
	while (tempx != NULL) {
		while (tempy != NULL) {
			fwrite(&(tempy->student), sizeof(Student), 1, file);
			tempy = tempy->nexty;
		}
		tempx = tempx->nextx;
		tempy = tempx;
	}
	fclose(file);
}
void save_math_student(struct Node_Student* head) {
	FILE* file = fopen("./student_math.txt", "w");
	struct Node_Student* tempx = head->nextx;
	struct Node_Student* tempy = head->nextx;
	while (tempx != NULL) {
		while (tempy != NULL) {
			fwrite(&(tempy->student), sizeof(Student), 1, file);
			tempy = tempy->nexty;
		}
		tempx = tempx->nextx;
		tempy = tempx;
	}
	fclose(file);
}
void save_physics_student(struct Node_Student* head) {
	FILE* file = fopen("./student_physics.txt", "w");
	struct Node_Student* tempx = head->nextx;
	struct Node_Student* tempy = head->nextx;
	while (tempx != NULL) {
		while (tempy != NULL) {
			fwrite(&(tempy->student), sizeof(Student), 1, file);
			tempy = tempy->nexty;
		}
		tempx = tempx->nextx;
		tempy = tempx;
	}
	fclose(file);
}
void save_computer_student(struct Node_Student* head) {
	FILE* file = fopen("./student_computer.txt", "w");
	struct Node_Student* tempx = head->nextx;
	struct Node_Student* tempy = head->nextx;
	while (tempx != NULL) {
		while (tempy != NULL) {
			fwrite(&(tempy->student), sizeof(Student), 1, file);
			tempy = tempy->nexty;
		}
		tempx = tempx->nextx;
		tempy = tempx;
	}
	fclose(file);
}
//��ȡ�ļ�
int load_software_student(struct Node_Student* head) {
	FILE* file = fopen("./student_software.txt", "r");
	if (!file) {
		return 0;
	}
	struct Node_Student* fresh = (Node_Student*)malloc(sizeof(Node_Student));
	fresh->nextx = NULL;
	fresh->nexty = NULL;
	struct Node_Student* tempx = head;
	struct Node_Student* tempy = head;
	while (fread(&fresh->student, sizeof(Student), 1, file) == 1) {
		if (strcmp(fresh->student.classname, "0") == 0) {
			tempx->nextx = fresh;
			tempx = fresh;
			tempy = tempx;
		}
		else {
			tempy->nexty = fresh;
			tempy = fresh;
		}
		fresh = (Node_Student*)malloc(sizeof(Node_Student));
		fresh->nextx = NULL;
		fresh->nexty = NULL;
	}
	free(fresh);
	fclose(file);
	return 1;
}
int load_physics_student(struct Node_Student* head) {
	FILE* file = fopen("./student_physics.txt", "r");
	if (!file) {
		return 0;
	}
	struct Node_Student* fresh = (Node_Student*)malloc(sizeof(Node_Student));
	fresh->nextx = NULL;
	fresh->nexty = NULL;
	struct Node_Student* tempx = head;
	struct Node_Student* tempy = head;
	while (fread(&fresh->student, sizeof(Student), 1, file) == 1) {
		if (strcmp(fresh->student.classname, "0") == 0) {
			tempx->nextx = fresh;
			tempx = fresh;
			tempy = tempx;
		}
		else {
			tempy->nexty = fresh;
			tempy = fresh;
		}
		fresh = (Node_Student*)malloc(sizeof(Node_Student));
		fresh->nextx = NULL;
		fresh->nexty = NULL;
	}
	free(fresh);
	fclose(file);
	return 1;
}
int load_math_student(struct Node_Student* head) {
	FILE* file = fopen("./student_math.txt", "r");
	if (!file) {
		return 0;
	}
	struct Node_Student* fresh = (Node_Student*)malloc(sizeof(Node_Student));
	fresh->nextx = NULL;
	fresh->nexty = NULL;
	struct Node_Student* tempx = head;
	struct Node_Student* tempy = head;
	while (fread(&fresh->student, sizeof(Student), 1, file) == 1) {
		if (strcmp(fresh->student.classname, "0") == 0) {
			tempx->nextx = fresh;
			tempx = fresh;
			tempy = tempx;
		}
		else {
			tempy->nexty = fresh;
			tempy = fresh;
		}
		fresh = (Node_Student*)malloc(sizeof(Node_Student));
		fresh->nextx = NULL;
		fresh->nexty = NULL;
	}
	free(fresh);
	fclose(file);
	return 1;
}
int load_computer_student(struct Node_Student* head) {
	FILE* file = fopen("./student_computer.txt", "r");
	if (!file) {
		return 0;
	}
	struct Node_Student* fresh = (Node_Student*)malloc(sizeof(Node_Student));
	fresh->nextx = NULL;
	fresh->nexty = NULL;
	struct Node_Student* tempx = head;
	struct Node_Student* tempy = head;
	while (fread(&fresh->student, sizeof(Student), 1, file) == 1) {
		if (strcmp(fresh->student.classname, "0") == 0) {
			tempx->nextx = fresh;
			tempx = fresh;
			tempy = tempx;
		}
		else {
			tempy->nexty = fresh;
			tempy = fresh;
		}
		fresh = (Node_Student*)malloc(sizeof(Node_Student));
		fresh->nextx = NULL;
		fresh->nexty = NULL;
	}
	free(fresh);
	fclose(file);
	return 1;
}
//
double getgpa(double score)
{
	if (score >= 90)
		return 4.0;
	else if (score >= 87)
		return 3.7;
	else if (score >= 84)
		return 3.3;
	else if (score >= 80)
		return 3.0;
	else if (score >= 77)
		return 2.7;
	else if (score >= 74)
		return 2.3;
	else if (score >= 70)
		return 2.0;
	else if (score >= 77)
		return 1.7;
	else if (score >= 74)
		return 1.3;
	else if (score >= 70)
		return 1.0;
	else
		return 0.0;
}
int judgepass(double score) {
	if (score < 60) {
		return 0;
	}
	return 1;
}
char* judgenum() {
	char* str;
	int size = 9;
	int len = 0;
	char ch;
	str = (char*)malloc(size);

	while ((ch = getchar()) != '\n') {
		if (len >= size) {
			size *= 2;
			str = (char*)realloc(str, size);
		}
		*(str + len) = ch;
		len++;
	}
	*(str + len) = '\0';

	int t = 0;
	for (int i = 0; i < strlen(str); i++) {
		if ((*(str + i) < '0') || *(str + i) > '9') {
			t = 1;
			break;
		}
	}
	if ((strlen(str) == 8) && t == 0) {
		return str;
	}
	else {
		printf("�������\n");
		system("pause");
		judgenum();
	}
}

void judgegrade(struct Node_Student* head) {
	char b[10];
	b[0] = head->student.stunum[2];
	b[1] = head->student.stunum[3];
	b[2] = '\0';
	char c[5] = "��";
	strcat(b, c);
	strcpy(head->student.grade, b);
}
//ɾ��ѧ��
int teacher_delete_a_student(struct Node_Student* head) {
	struct Node_Student* temp = head->nextx;
	while (temp != NULL) {
		if (strcmp(stunumglobal_teacher, temp->student.stunum) == 0) {
			printf("����:%s\nѧԺ:%s\n����Ա:%s\n�Ա�:%s\n�꼶:%s\n", temp->student.name, temp->student.collegeof, temp->student.teachername, temp->student.gender, temp->student.grade);
			return 1;
		}
		temp = temp->nextx;
	}
	//printf("δ�ҵ���ѧ��");

	
	return 0;
	//��ȫ
}
void delete_student(struct Node_Student* head_software, struct Node_Student* head_physics, struct Node_Student* head_computer, struct Node_Student* head_math) {
	struct Node_Student* temp = head_software->nextx;
	struct Node_Student* p = head_software;
	struct Node_Student* deletenodeb = (struct Node_Student*)malloc(sizeof(Node_Student));
	deletenodeb->nextx = NULL;
	deletenodeb->nexty = NULL;
	struct Node_Student* deletenodea = deletenodeb;

	printf("�������ѧ��ѧ��");
	strcpy(stunumglobal_teacher, judgenum());
	int t1 = teacher_delete_a_student(head_software);
	int t2 = teacher_delete_a_student(head_math);
	int t3 = teacher_delete_a_student(head_physics);
	int t4 = teacher_delete_a_student(head_computer);
	bool find = false;
	if (t1 || t2 || t3 || t4) {
		while (1) {
			printf("��ȷ���Ƿ�Ҫɾ����ѧ�������ǣ�������1������������0");
			char a = _getch();//һ���ַ�����������
			switch (a) {
			case '0':
				printf("ȡ��ɾ����ѧ��");
				system("pause");
				return;
			case '1':
				log_file = fopen(LogName, "a");
				fprintf(log_file, "%s  ", LogTime);
				fprintf(log_file, "ɾ��ѧ�� %s \n\n", temp->student.name);

				while (strcmp(temp->student.stunum, stunumglobal_teacher) != 0) {
					p = temp;
					temp = temp->nextx;
				}
				deletenodeb = temp;
				temp = temp->nextx;
				p->nextx = temp;
				while (deletenodeb != NULL) {
					deletenodea = deletenodeb;
					deletenodeb = deletenodeb->nexty;
					free(deletenodea);
				}
				printf("��ɾ����ѧ��");
				system("pause");
				return;
			default:
				printf("��������ȷ�ĸ�ʽ");
				system("pause");
			}
		}
	}
	else {
		printf("δ�ҵ���ѧ��");
		system("pause");
		return;
	}
	system("cls");
}
void get_classnum(struct Node_Student* head) {
	char b[10];
	b[0] = head->student.stunum[4];
	b[1] = head->student.stunum[5];
	b[2] = '\0';
	head->student.classnum = ((int)head->student.stunum[4] - 48) * 10 + (int)head->student.stunum[5] - 48;

}
void setPrintColor(int color) {
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}
void gotoXY(int x, int y)
{
	COORD c;
	c.X = x - 1;
	c.Y = y - 1;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), c);
}
void clear(int x, int y, int w, int h)
{
	for (int i = 0; i < h; i++) {
		gotoXY(x, y + i);
		for (int j = 0; j < w; j++) putchar(' ');
	}
}
void calculate_gpa(struct Node_Student* temp) {
	double total = 0;
	double sum_score, sum_power, sum_gpa;
	double score, power, gpa;
	score = power = gpa = sum_gpa = sum_power = sum_score = 0;
	temp = temp->nexty;
	while (temp != NULL) {
		total = total + temp->student.credit;
		sum_gpa = sum_gpa + (temp->student.credit) * (temp->student.GPA);
		temp = temp->nexty;
	}
	if (total != 0) {
		gpa = sum_gpa / total;
	plink_list_head->recommend_exempt_scores[0] = gpa;
	plink_list_head->recommend_exempt_scores[1] = gpa;
	}
	else {
		plink_list_head->recommend_exempt_scores[0] = 0;
		plink_list_head->recommend_exempt_scores[1] = 0;
	}
	return;
}
void student_calculate_gpa(struct Node_Student* temp) {
	double total = 0;
	double sum_score, sum_power, sum_gpa;
	double score, power, gpa;
	score = power = gpa = sum_gpa = sum_power = sum_score = 0;
	struct Node_Student* p = temp->nexty;
	while (p != NULL) {
		total = total + p->student.credit;
		sum_gpa = sum_gpa + (p->student.credit) * (p->student.GPA);
		p = p->nexty;
	}
	gpa = sum_gpa / total;
	temp->student.GPA = gpa;
	return;
}
void student_calculate_ranking(struct Node_Student* head, struct Node_Student* temp) {
	int total = 1;
	struct Node_Student* p = head->nextx;
	while (p != NULL) {
		if (temp->student.GPA < p->student.GPA) {
			total++;
		}
		p = p->nextx;
	}
	printf("��ǰƽ����������Ϊ��%d\n", total);
}
//////////////������
void change_student_information(struct Node_Student* temp) {
	system("cls");
	struct Node_Student* p = temp;
	int userChoose = 0;
	int t = 0;
	while (1) {
		// ----------------- ��ӡ���� -----------------
		if (userChoose == 0) setPrintColor(0x6f);
		gotoXY(1, 1);
		printf("����ѧԺ��%s", temp->student.collegeof);
		if (userChoose == 0) setPrintColor(0x0f);
		if (userChoose == 1) setPrintColor(0x6f);
		gotoXY(1, 3);
		printf("����Ա���֣�%s", temp->student.teachername);
		if (userChoose == 1) setPrintColor(0x0f);
		if (userChoose == 2) setPrintColor(0x6f);
		gotoXY(1, 5);
		printf("ѧ�ţ�%s", temp->student.stunum);
		if (userChoose == 2) setPrintColor(0x0f);
		if (userChoose == 3) setPrintColor(0x6f);
		gotoXY(1, 7);
		printf("���֣�%s", temp->student.name);
		if (userChoose == 3) setPrintColor(0x0f);
		if (userChoose == 4) setPrintColor(0x6f);
		gotoXY(1, 9);
		printf("�Ա�%s", temp->student.gender);
		if (userChoose == 4) setPrintColor(0x0f);
		if (userChoose == 5) setPrintColor(0x6f);
		gotoXY(1, 11);
		printf("�༶��%d", temp->student.classnum);
		if (userChoose == 5) setPrintColor(0x0f);
		if (userChoose == 6) setPrintColor(0x6f);
		gotoXY(1, 13);
		printf("�绰���룺%s", temp->student.tel);
		if (userChoose == 6) setPrintColor(0x0f);
		if (userChoose == 7) setPrintColor(0x6f);
		gotoXY(1, 15);
		printf("�꼶��%s", temp->student.grade);
		if (userChoose == 7) setPrintColor(0x0f);

		//FILE* fp = fopen(LogName, "a");
		//fprintf(fp, "%s\t", LogTime);
		//��Ҫ��ʦ�ṹ��
		// ---------------- �����û����� --------------
		char input = _getch();
		// -------------�ж��Ƿ������»��ǻس�------------
		switch (input) {
		case 'W':
		case 'w':
			userChoose -= 1;
			if (userChoose == -1) userChoose = 7;
			break;
		case 'S':
		case 's':
			userChoose = (userChoose + 1) % 8;
			break;
		case '\r':
			//clear(3, 2, 80, 20);
			switch (userChoose) {
			case 0:
				printf("\n\n");
				t = 1;
				printf("�������޸ĺ��ѧԺ\n");
				scanf("%s", temp->student.collegeof);

				log_file = fopen(LogName, "a");
				fprintf(log_file, "%s  ", LogTime);
				fprintf(log_file, "�޸�ѧ�� %s \n\n", temp->student.name);
				break;
			case 1:
				printf("\n\n");

				t = 1;
				printf("�������޸ĺ�ĸ���Ա��ʦ����\n");
				scanf("%s", temp->student.teachername);
				log_file = fopen(LogName, "a");
				fprintf(log_file, "%s  ", LogTime);
				fprintf(log_file, "�޸�ѧ�� %s \n\n", temp->student.name);

				while (temp->nexty != NULL) {
					temp = temp->nexty;
					strcpy(temp->student.teachername, p->student.teachername);
				}
				break;
			case 2:
				printf("\n\n");

				t = 1;
				printf("�������޸ĺ��ѧ��\n");
				scanf("%s", temp->student.stunum);

				log_file = fopen(LogName, "a");
				fprintf(log_file, "%s  ", LogTime);
				fprintf(log_file, "�޸�ѧ�� %s \n\n", temp->student.name);

				while (temp->nexty != NULL) {
					temp = temp->nexty;
					strcpy(temp->student.stunum, p->student.stunum);
				}
				break;
			case 3:
				printf("\n\n");

				t = 1;
				printf("�������޸ĺ������\n");
				scanf("%s", temp->student.name);

				log_file = fopen(LogName, "a");
				fprintf(log_file, "%s  ", LogTime);
				fprintf(log_file, "�޸�ѧ�� %s \n\n", temp->student.name);

				while (temp->nexty != NULL) {
					temp = temp->nexty;
					strcpy(temp->student.name, p->student.name);
				}
				break;
			case 4:
				printf("\n\n");

				t = 1;
				printf("�������޸ĺ���Ա�\n");
				scanf("%s", temp->student.gender);

				log_file = fopen(LogName, "a");
				fprintf(log_file, "%s  ", LogTime);
				fprintf(log_file, "�޸�ѧ�� %s \n\n", temp->student.name);

				while (temp->nexty != NULL) {
					temp = temp->nexty;
					strcpy(temp->student.gender, p->student.gender);
				}
				break;
			case 5:
				printf("\n\n");

				t = 1;
				printf("�������޸ĺ�İ༶\n");
				scanf("%d", &temp->student.classnum);

				log_file = fopen(LogName, "a");
				fprintf(log_file, "%s  ", LogTime);
				fprintf(log_file, "�޸�ѧ�� %s \n\n", temp->student.name);

				while (temp->nexty != NULL) {
					temp = temp->nexty;
					temp->student.classnum = p->student.classnum;
				}
				break;
			case 6:
				printf("\n\n");

				t = 1;
				printf("�������޸ĺ�ĵ绰����\n");
				scanf("%s", temp->student.tel);

				log_file = fopen(LogName, "a");
				fprintf(log_file, "%s  ", LogTime);
				fprintf(log_file, "�޸�ѧ�� %s \n\n", temp->student.name);

				while (temp->nexty != NULL) {
					temp = temp->nexty;
					strcpy(temp->student.tel, p->student.tel);
				}
				break;
			}
			break;
		}
		if (t == 1)break;//����ѭ��
	}


	system("cls");
	
}

void change_student_score(struct Node_Student* temp) {
	char a[100];
	printf("������Ҫ�޸ĵ�ѧ��\n");
	scanf("%s", a);
	while (temp->nexty != NULL) {
		temp = temp->nexty;
		if (strcmp(temp->student.classname, a) == 0) {
			printf("��Ŀ��%s ԭ������%lf\n", temp->student.classname, temp->student.score);
			break;
		}
	}
	if (temp == NULL) {
		printf("��ѧ��û�иÿγ�\n");
		return;
	}
	printf("�������޸ĺ����\n");
	scanf("%lf", &temp->student.score);
	temp->student.GPA = getgpa(temp->student.score);
	//��Ҫ��ʦ�ṹ��
	//FILE *fp=fopen(LogName, "a");
	//fprintf(fp,"%s\t",LogTime);
}
//��ʦ��ӡ�Լ���ѧ��ĳɼ�
void teacher_print_own_student_score(struct Node_Student* head_software, struct Node_Student* head_physics, struct Node_Student* head_computer, struct Node_Student* head_math) {
	struct Node_Student* p = (struct Node_Student*)malloc(sizeof(struct Node_Student));
	struct Node_Student* p0 = (struct Node_Student*)malloc(sizeof(struct Node_Student));
	//���head_part_student��Ҫ��������������
	struct Node_Student* head_part_student = (struct Node_Student*)malloc(sizeof(struct Node_Student));
	struct Node_Student* fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
	fresh->nextx = NULL;
	head_part_student->nextx = NULL;
	head_part_student->nexty = NULL;
	struct Node_Student* temp = head_part_student;
	p0 = head_software;
	p = head_software;
	struct Node_Teacher* teacher_temp = teacher_global;

	while (teacher_temp != NULL) {
		p0 = head_software;//����ָ��
		p = head_software;//����ָ��
		while (p->nextx != NULL) {
			p = p->nextx;
			p0 = p;
			while (p0->nexty != NULL) {
				p0 = p0->nexty;
				for (int i = 0; i < 20; i++) {
					if (strcmp(p0->student.classname, teacher_temp->teacher.subject) == 0 && strcmp(p0->student.collegeof, teacher_temp->teacher.class_collegeof) == 0 && strcmp(p0->student.grade, teacher_temp->teacher.grade) == 0 && p0->student.classnum==teacher_temp->teacher.class_num[i]) {
						fresh->student = p0->student;
						temp->nextx = fresh;
						temp = temp->nextx;
						fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
						fresh->nextx = NULL;
					}
				}
			}
		}
		p = head_math;
		p0 = p;
		while (p->nextx != NULL) {
			p = p->nextx;
			p0 = p;
			while (p0->nexty != NULL) {
				p0 = p0->nexty;
				for (int i = 0; i < 20; i++) {
					if (strcmp(p0->student.classname, teacher_temp->teacher.subject) == 0 && strcmp(p0->student.collegeof, teacher_temp->teacher.class_collegeof) == 0 && strcmp(p0->student.grade, teacher_temp->teacher.grade) == 0 && p0->student.classnum == teacher_temp->teacher.class_num[i]) {
						fresh->student = p0->student;
						temp->nextx = fresh;
						temp = temp->nextx;
						fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
						fresh->nextx = NULL;
					}
				}
			}
		}
		p = head_physics;
		p0 = p;
		while (p->nextx != NULL) {
			p = p->nextx;
			p0 = p;
			while (p0->nexty != NULL) {
				p0 = p0->nexty;
				for (int i = 0; i < 20; i++) {
					if (strcmp(p0->student.classname, teacher_temp->teacher.subject) == 0 && strcmp(p0->student.collegeof, teacher_temp->teacher.class_collegeof) == 0 && strcmp(p0->student.grade, teacher_temp->teacher.grade) == 0 && p0->student.classnum == teacher_temp->teacher.class_num[i]) {
						fresh->student = p0->student;
						temp->nextx = fresh;
						temp = temp->nextx;
						fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
						fresh->nextx = NULL;
					}
				}
			}
		}
		p = head_computer;
		p0 = p;
		while (p->nextx != NULL) {
			p = p->nextx;
			p0 = p;
			while (p0->nexty != NULL) {
				p0 = p0->nexty;
				for (int i = 0; i < 20; i++) {
					if (strcmp(p0->student.classname, teacher_temp->teacher.subject) == 0 && strcmp(p0->student.collegeof, teacher_temp->teacher.class_collegeof) == 0 && strcmp(p0->student.grade, teacher_temp->teacher.grade) == 0 && p0->student.classnum == teacher_temp->teacher.class_num[i]) {
						fresh->student = p0->student;
						temp->nextx = fresh;
						temp = temp->nextx;
						fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
						fresh->nextx = NULL;
					}
				}
			}
		}
		teacher_temp = teacher_temp->next2;
	}
	p0 = head_part_student->nextx;
	if (p0 == NULL) {
		printf("û��ѧ��");
		system("pause");
		return;
	}
	if (p0->nextx != NULL) {
		p = p0->nextx;
	}
	int t = 1;
	while (t) {
		t = 0;
		while (p != NULL) {
			if (p0->student.score < p->student.score) {
				t = 1;
				fresh->student = p0->student;
				p0->student = p->student;
				p->student = p0->student;
			}
			p0 = p;
			p = p->nextx;
		}
	}
	p = head_part_student;
	while (p->nextx != NULL) {
		p = p->nextx;
		printf("ѧ�ڣ�%s\t��Ŀ��%s\tѧ��������%s\t�γ̷�����%lf\t���㣺%lf\t�޶���ʽ��%s\t�Ƿ���Ч��%s\n", p->student.classtime, p->student.classname, p->student.name, p->student.score, p->student.GPA, p->student.way, p->student.effective_or_not);
	}
}
//�鿴��������ѧ���ɼ�
void teacher_print_all_student_score(struct Node_Student* head_software, struct Node_Student* head_physics, struct Node_Student* head_computer, struct Node_Student* head_math) {
	system("cls");
	struct Node_Student* p = (struct Node_Student*)malloc(sizeof(struct Node_Student));
	struct Node_Student* p0 = (struct Node_Student*)malloc(sizeof(struct Node_Student));

	struct Node_Student* head_part_student = (struct Node_Student*)malloc(sizeof(struct Node_Student));
	struct Node_Student* fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
	head_part_student->nextx = NULL;
	head_part_student->nexty = NULL;
	struct Node_Student* temp = head_part_student;//�½�����
	struct Node_Teacher* teacher_temp = teacher_global;
	while (teacher_temp != NULL) {
		p0 = head_software;//����ָ��
		p = head_software;//����ָ��
		while (p->nextx != NULL) {
			p = p->nextx;
			p0 = p;
			while (p0->nexty != NULL) {
				p0 = p0->nexty;
				if (strcmp(p0->student.classname, teacher_temp->teacher.subject) == 0 && strcmp(p0->student.collegeof, teacher_temp->teacher.class_collegeof) == 0 && strcmp(p0->student.grade, teacher_temp->teacher.grade) == 0) {
					fresh->student = p0->student;
					temp->nextx = fresh;
					temp = temp->nextx;
					fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
					fresh->nextx = NULL;
				}
			}
		}
		p = head_math;
		p0 = p;
		while (p->nextx != NULL) {
			p = p->nextx;
			p0 = p;
			while (p0->nexty != NULL) {
				p0 = p0->nexty;
				if (strcmp(p0->student.classname, teacher_temp->teacher.subject) == 0 && strcmp(p0->student.collegeof, teacher_temp->teacher.class_collegeof) == 0 && strcmp(p0->student.grade, teacher_temp->teacher.grade) == 0) {
					temp->nextx = fresh;
					fresh->student = p0->student;
					temp = temp->nextx;
					fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
					fresh->nextx = NULL;
					fresh->nexty = NULL;
				}
			}
		}
		p = head_physics;
		p0 = p;
		while (p->nextx != NULL) {
			p = p->nextx;
			p0 = p;
			while (p0->nexty != NULL) {
				p0 = p0->nexty;
				if (strcmp(p0->student.classname, teacher_temp->teacher.subject) == 0 && strcmp(p0->student.collegeof, teacher_temp->teacher.class_collegeof) == 0 && strcmp(p0->student.grade, teacher_temp->teacher.grade) == 0) {
					temp->nextx = fresh;
					fresh->student = p0->student;
					temp = temp->nextx;
					fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
					fresh->nextx = NULL;
				}
			}
		}
		p = head_computer;
		p0 = p;
		while (p->nextx != NULL) {
			p = p->nextx;
			p0 = p;
			while (p0->nexty != NULL) {
				p0 = p0->nexty;
				if (strcmp(p0->student.classname, teacher_temp->teacher.subject) == 0 && strcmp(p0->student.collegeof, teacher_temp->teacher.class_collegeof) == 0 && strcmp(p0->student.grade, teacher_temp->teacher.grade) == 0) {
					temp->nextx = fresh;
					fresh->student = p0->student;
					temp = temp->nextx;
					fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
					fresh->nextx = NULL;
				}
			}
		}
		teacher_temp = teacher_temp->next2;
	}
	p0 = head_part_student->nextx;
	if (p0 == NULL) {
		printf("û��ѧ��");
		system("pause");
		return;
	}
	p = p0->nextx;
	int t = 1;
	while (t) {
		t = 0;
		while (p != NULL) {
			if (p0->student.score < p->student.score) {
				t = 1;
				fresh->student = p0->student;
				p0->student = p->student;
				p->student = fresh->student;
			}
			p0 = p;
			p = p->nextx;
		}
	}
	p = head_part_student;
	while (p->nextx != NULL) {
		p = p->nextx;
		printf("ѧ�ڣ�%s\t��Ŀ��%s\tѧ��������%s\t�γ̷�����%lf\t���㣺%lf\t�޶���ʽ��%s\t�Ƿ���Ч��%s\n", p->student.classtime, p->student.classname, p->student.name, p->student.score, p->student.GPA, p->student.way, p->student.effective_or_not);
	}
}

void print_all_score(struct Node_Student* temp) {
	while (temp->nexty != NULL) {
		temp = temp->nexty;
		printf("��Ŀ��%s\tѧ�֣�%lf\t�ɼ���%lf\t���㣺%lf\n", temp->student.classname, temp->student.credit, temp->student.score, temp->student.GPA);
	}
	return;
}


void print_a_class_score(struct Node_Student* head_software, struct Node_Student* head_physics, struct Node_Student* head_computer, struct Node_Student* head_math) {
	system("cls");
	struct Node_Student* p = (struct Node_Student*)malloc(sizeof(struct Node_Student));
	struct Node_Student* p0 = (struct Node_Student*)malloc(sizeof(struct Node_Student));

	struct Node_Student* head_part_student = (struct Node_Student*)malloc(sizeof(struct Node_Student));
	struct Node_Student* fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
	head_part_student->nextx = NULL;
	head_part_student->nexty = NULL;
	struct Node_Student* temp = head_part_student;//�½�����

	while (1) {
		int t = 0;
		int userchoose = 0;
		if (userchoose == 0)setPrintColor(0x6f);
		gotoXY(1, 5);
		printf("1��20�꼶\n");
		if (userchoose == 0)setPrintColor(0x0f);
		if (userchoose == 1)setPrintColor(0x6f);
		gotoXY(1, 7);
		printf("2��21��\n");
		if (userchoose == 1)setPrintColor(0x0f);
		if (userchoose == 2)setPrintColor(0x6f);
		gotoXY(1, 9);
		printf("3��22��\n");
		if (userchoose == 2)setPrintColor(0x0f);
		if (userchoose == 3)setPrintColor(0x6f);
		gotoXY(1, 11);
		printf("4��23��\n");
		if (userchoose == 3)setPrintColor(0x0f);

		char input0 = _getch();
		switch (input0) {
		case 72:
		case 'W':
		case'w':userchoose -= 1;
			if (userchoose == -1) userchoose = 3;
			break;
		case 80:
		case 'S':
		case's':userchoose = (userchoose + 1) % 4;
			break;
		case 27:t = 1;
			break;
		case'\r':
			system("cls");
			t = 1;
			switch (userchoose) {
			case 0:
			{
				p0 = head_software;//����ָ��
				p = head_software;//����ָ��while (p->nextx != NULL) 
				p = p->nextx;
				p0 = p;
				while (p->nextx != NULL) {
					p = p->nextx;
					p0 = p;
					while (p0->nexty != NULL) {
						p0 = p0->nexty;
						if (strcmp(p0->student.classname, g_class_name) == 0 && strcmp(p0->student.grade, "20��") == 0) {
							fresh->student = p0->student;
							temp->nextx = fresh;
							temp = temp->nextx;
							fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
							fresh->nextx = NULL;
						}
					}
				}
				p = head_math;
				p0 = p;
				while (p->nextx != NULL) {
					p = p->nextx;
					p0 = p;
					while (p0->nexty != NULL) {
						p0 = p0->nexty;
						if (strcmp(p0->student.classname, g_class_name) == 0 && strcmp(p0->student.grade, "20��") == 0) {
							fresh->student = p0->student;
							temp->nextx = fresh;
							temp = temp->nextx;
							fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
							fresh->nextx = NULL;
						}
					}
				}
				p = head_physics;
				p0 = p;
				while (p->nextx != NULL) {
					p = p->nextx;
					p0 = p;
					while (p0->nexty != NULL) {
						p0 = p0->nexty;
						if (strcmp(p0->student.classname, g_class_name) == 0 && strcmp(p0->student.grade, "20��") == 0) {
							fresh->student = p0->student;
							temp->nextx = fresh;
							temp = temp->nextx;
							fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
							fresh->nextx = NULL;
						}
					}
				}
				p = head_computer;
				p0 = p;
				while (p->nextx != NULL) {
					p = p->nextx;
					p0 = p;
					while (p0->nexty != NULL) {
						p0 = p0->nexty;
						if (strcmp(p0->student.classname, g_class_name) == 0 && strcmp(p0->student.grade, "20��") == 0) {
							fresh->student = p0->student;
							temp->nextx = fresh;
							temp = temp->nextx;
							fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
							fresh->nextx = NULL;
						}
					}
				}
				p0 = head_part_student->nextx;
				if (p0->nextx == NULL) {
					printf("û�иÿγ�");
					system("pause");
					return;
				}

				p = p0->nextx;
				int op = 1;
				while (op) {
					op = 0;
					while (p != NULL) {
						if (p0->student.score < p->student.score) {
							op = 1;
							fresh->student = p0->student;
							p0->student = p->student;
							p->student = fresh->student;
						}
						p0 = p;
						p = p->nextx;
					}
				}
				p = head_part_student;
				while (p->nextx != NULL) {
					p = p->nextx;
					printf("ѧ�ڣ�%s\t��Ŀ��%s\tѧ��������%s\t�γ̷�����%lf\t���㣺%lf\t�޶���ʽ��%s\t�Ƿ���Ч��%s\n", p->student.classtime, p->student.classname, p->student.name, p->student.score, p->student.GPA, p->student.way, p->student.effective_or_not);
				}
			}
			system("pause");
			system("cls");
			break;
			case 1:
			{
				p0 = head_software;//����ָ��
				p = head_software;//����ָ��while (p->nextx != NULL) 
				p = p->nextx;
				p0 = p;
				while (p->nextx != NULL) {
					p = p->nextx;
					p0 = p;
					while (p0->nexty != NULL) {
						p0 = p0->nexty;
						if (strcmp(p0->student.classname, g_class_name) == 0 && strcmp(p0->student.grade, "21��") == 0) {
							fresh->student = p0->student;
							temp->nextx = fresh;
							temp = temp->nextx;
							fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
							fresh->nextx = NULL;
						}
					}
				}
				p = head_math;
				p0 = p;
				while (p->nextx != NULL) {
					p = p->nextx;
					p0 = p;
					while (p0->nexty != NULL) {
						p0 = p0->nexty;
						if (strcmp(p0->student.classname, g_class_name) == 0 && strcmp(p0->student.grade, "21��") == 0) {
							fresh->student = p0->student;
							temp->nextx = fresh;
							temp = temp->nextx;
							fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
							fresh->nextx = NULL;
						}
					}
				}
				p = head_physics;
				p0 = p;
				while (p->nextx != NULL) {
					p = p->nextx;
					p0 = p;
					while (p0->nexty != NULL) {
						p0 = p0->nexty;
						if (strcmp(p0->student.classname, g_class_name) == 0 && strcmp(p0->student.grade, "21��") == 0) {
							fresh->student = p0->student;
							temp->nextx = fresh;
							temp = temp->nextx;
							fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
							fresh->nextx = NULL;
						}
					}
				}
				p = head_computer;
				p0 = p;
				while (p->nextx != NULL) {
					p = p->nextx;
					p0 = p;
					while (p0->nexty != NULL) {
						p0 = p0->nexty;
						if (strcmp(p0->student.classname, g_class_name) == 0 && strcmp(p0->student.grade, "21��") == 0) {
							fresh->student = p0->student;
							temp->nextx = fresh;
							temp = temp->nextx;
							fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
							fresh->nextx = NULL;
						}
					}
				}
				p0 = head_part_student->nextx;
				if (p0->nextx == NULL) {
					printf("û�иÿγ�");
					system("pause");
					return;
				}

				p = p0->nextx;
				int op = 1;
				while (op) {
					op = 0;
					while (p != NULL) {
						if (p0->student.score < p->student.score) {
							op = 1;
							fresh->student = p0->student;
							p0->student = p->student;
							p->student = fresh->student;
						}
						p0 = p;
						p = p->nextx;
					}
				}
				p = head_part_student;
				while (p->nextx != NULL) {
					p = p->nextx;
					printf("ѧ�ڣ�%s\t��Ŀ��%s\tѧ��������%s\t�γ̷�����%lf\t���㣺%lf\t�޶���ʽ��%s\t�Ƿ���Ч��%s\n", p->student.classtime, p->student.classname, p->student.name, p->student.score, p->student.GPA, p->student.way, p->student.effective_or_not);
				}
			}
			system("pause");
			system("cls");
			break;
			case 2:
			{
				p0 = head_software;//����ָ��
				p = head_software;//����ָ��while (p->nextx != NULL) 
				p = p->nextx;
				p0 = p;
				while (p->nextx != NULL) {
					p = p->nextx;
					p0 = p;
					while (p0->nexty != NULL) {
						p0 = p0->nexty;
						if (strcmp(p0->student.classname, g_class_name) == 0 && strcmp(p0->student.grade, "22��") == 0) {
							fresh->student = p0->student;
							temp->nextx = fresh;
							temp = temp->nextx;
							fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
							fresh->nextx = NULL;
						}
					}
				}
				p = head_math;
				p0 = p;
				while (p->nextx != NULL) {
					p = p->nextx;
					p0 = p;
					while (p0->nexty != NULL) {
						p0 = p0->nexty;
						if (strcmp(p0->student.classname, g_class_name) == 0 && strcmp(p0->student.grade, "22��") == 0) {
							fresh->student = p0->student;
							temp->nextx = fresh;
							temp = temp->nextx;
							fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
							fresh->nextx = NULL;
						}
					}
				}
				p = head_physics;
				p0 = p;
				while (p->nextx != NULL) {
					p = p->nextx;
					p0 = p;
					while (p0->nexty != NULL) {
						p0 = p0->nexty;
						if (strcmp(p0->student.classname, g_class_name) == 0 && strcmp(p0->student.grade, "22��") == 0) {
							fresh->student = p0->student;
							temp->nextx = fresh;
							temp = temp->nextx;
							fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
							fresh->nextx = NULL;
						}
					}
				}
				p = head_computer;
				p0 = p;
				while (p->nextx != NULL) {
					p = p->nextx;
					p0 = p;
					while (p0->nexty != NULL) {
						p0 = p0->nexty;
						if (strcmp(p0->student.classname, g_class_name) == 0 && strcmp(p0->student.grade, "22��") == 0) {
							fresh->student = p0->student;
							temp->nextx = fresh;
							temp = temp->nextx;
							fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
							fresh->nextx = NULL;
						}
					}
				}
				p0 = head_part_student->nextx;
				if (p0->nextx == NULL) {
					printf("û�иÿγ�");
					system("pause");
					return;
				}

				p = p0->nextx;
				int op = 1;
				while (op) {
					op = 0;
					while (p != NULL) {
						if (p0->student.score < p->student.score) {
							op = 1;
							fresh->student = p0->student;
							p0->student = p->student;
							p->student = fresh->student;
						}
						p0 = p;
						p = p->nextx;
					}
				}
				p = head_part_student;
				while (p->nextx != NULL) {
					p = p->nextx;
					printf("ѧ�ڣ�%s\t��Ŀ��%s\tѧ��������%s\t�γ̷�����%lf\t���㣺%lf\t�޶���ʽ��%s\t�Ƿ���Ч��%s\n", p->student.classtime, p->student.classname, p->student.name, p->student.score, p->student.GPA, p->student.way, p->student.effective_or_not);
				}
			}
			system("pause");
			system("cls");
			break;
			case 3:
			{
				p0 = head_software;//����ָ��
				p = head_software;//����ָ��while (p->nextx != NULL) 
				p = p->nextx;
				p0 = p;
				while (p->nextx != NULL) {
					p = p->nextx;
					p0 = p;
					while (p0->nexty != NULL) {
						p0 = p0->nexty;
						if (strcmp(p0->student.classname, g_class_name) == 0 && strcmp(p0->student.grade, "23��") == 0) {
							fresh->student = p0->student;
							temp->nextx = fresh;
							temp = temp->nextx;
							fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
							fresh->nextx = NULL;
						}
					}
				}
				p = head_math;
				p0 = p;
				while (p->nextx != NULL) {
					p = p->nextx;
					p0 = p;
					while (p0->nexty != NULL) {
						p0 = p0->nexty;
						if (strcmp(p0->student.classname, g_class_name) == 0 && strcmp(p0->student.grade, "23��") == 0) {
							fresh->student = p0->student;
							temp->nextx = fresh;
							temp = temp->nextx;
							fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
							fresh->nextx = NULL;
						}
					}
				}
				p = head_physics;
				p0 = p;
				while (p->nextx != NULL) {
					p = p->nextx;
					p0 = p;
					while (p0->nexty != NULL) {
						p0 = p0->nexty;
						if (strcmp(p0->student.classname, g_class_name) == 0 && strcmp(p0->student.grade, "23��") == 0) {
							fresh->student = p0->student;
							temp->nextx = fresh;
							temp = temp->nextx;
							fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
							fresh->nextx = NULL;
						}
					}
				}
				p = head_computer;
				p0 = p;
				while (p->nextx != NULL) {
					p = p->nextx;
					p0 = p;
					while (p0->nexty != NULL) {
						p0 = p0->nexty;
						if (strcmp(p0->student.classname, g_class_name) == 0 && strcmp(p0->student.grade, "23��") == 0) {
							fresh->student = p0->student;
							temp->nextx = fresh;
							temp = temp->nextx;
							fresh = (struct Node_Student*)malloc(sizeof(struct Node_Student));
							fresh->nextx = NULL;
						}
					}
				}
				p0 = head_part_student->nextx;
				if (p0->nextx == NULL) {
					printf("û�иÿγ�");
					system("pause");
					return;
				}

				p = p0->nextx;
				int op = 1;
				while (op) {
					op = 0;
					while (p != NULL) {
						if (p0->student.score < p->student.score) {
							op = 1;
							fresh->student = p0->student;
							p0->student = p->student;
							p->student = fresh->student;
						}
						p0 = p;
						p = p->nextx;
					}
				}
				p = head_part_student;
				while (p->nextx != NULL) {
					p = p->nextx;
					printf("ѧ�ڣ�%s\t��Ŀ��%s\tѧ��������%s\t�γ̷�����%lf\t���㣺%lf\t�޶���ʽ��%s\t�Ƿ���Ч��%s\n", p->student.classtime, p->student.classname, p->student.name, p->student.score, p->student.GPA, p->student.way, p->student.effective_or_not);
				}
			}
			system("pause");
			system("cls");
			break;
			}
		}
		if (t == 1) break;
		if (input0 == 27)break;
	}


	
}


#endif
